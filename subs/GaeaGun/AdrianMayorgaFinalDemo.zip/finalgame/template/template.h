///////////////////////////////////////////////////////////////////////
//
//  File				:	template.h
//  Classes				:	CTemplate
//  Description			:	The header for the template application file
//
////////////////////////////////////////////////////////////////////////
#ifndef TEMPLATE_H
#define TEMPLATE_H

// The main G3D header
#include <G3DAll.h>

class	CApp;

///////////////////////////////////////////////////////////////////////
// Class				:	CTemplate
// Description			:	This class encapsulates a single window
// Comments				:	Create different applets for different portions
//							of your game. For example, main game menu, loading screen
//							and the actual game are different applets each of which 
//							having its own game loop.
class CTemplate : public GApplet {
public:

					CTemplate(CApp	*app);
	virtual			~CTemplate();

					// The following functions are called to do specific actions
	virtual void	onInit();
	virtual void	onLogic();
	virtual void	onNetwork();
	virtual void	onSimulation(RealTime rdt, SimTime sdt, SimTime idt);
	virtual void	onGraphics(RenderDevice* rd);
	virtual void	onUserInput(UserInput* ui);
	virtual void	onCleanup();

protected:
					// Pointer to the application so we can access the global data
	CApp			*app;

					// A texture we use for this template
	TextureRef		texture;
	Color3			play;
	Color3			controls;
	Color3			quit;
	float			mY;

};


#endif




