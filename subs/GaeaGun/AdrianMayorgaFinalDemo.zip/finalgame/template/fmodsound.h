#include "fmod\fmod.hpp"
#include <stdio.h>
using namespace FMOD;
class GameSound
{
public:
	GameSound(std::string filename,bool loop);
    void Play();
	void Stop();


private:
    // Your main interaction point with FMOD
    FMOD::System*  m_system;

    // In the constructor we will create sounds from files on disk and store them in Sound objects
    FMOD::Sound*   m_sound;

    // Channels are used to keep tabs on a current playing sound
    FMOD::Channel* m_coolSoundChannel;

    //Music can be just another sound
}; 



GameSound::GameSound(std::string filename,bool loop)
 :m_system(0), m_sound(0), m_coolSoundChannel(0)
{
    // This creates your system object
    FMOD::System_Create(&m_system);
    // This initializes your system object with 100 channels, this value is a good one to start with
    // The other parameters just setup the object with default options
    m_system->init(100, FMOD_INIT_NORMAL, 0);

    // Creating a sound like this will load the entire file from disk with default options.    
    if(loop)
		m_system->createStream(filename.c_str(), FMOD_LOOP_NORMAL, 0, &m_sound);
	else
		m_system->createStream(filename.c_str(), FMOD_DEFAULT, 0, &m_sound);
  
}

// This function will play "CoolSound.wav" if it is not already being played.  I use this and call a similar
// function every time I shoot a machine gun.  This will ensure that the sound plays continuously while you are shooting
// but not start over at the beginning of the sound file if you keep calling the function.
void GameSound::Play()
{
  if(m_coolSoundChannel != NULL)
  {
        // If we are here, then we have played the sound at least once... lets check to see if it is currently playing
        bool isPlaying = false;
        m_coolSoundChannel->isPlaying(&isPlaying);
        if(!isPlaying)
        {
            // If it's not playing, we want to play it.  If it is, we don't want to, because that would restart the sound.
            // FMOD_CHANNEL_REUSE is a flag to re-use a previously existing channel.  
            // The "false" is a paused parameter.  You can start a sound paused if you want, and then change the volume
            // and then start it.
            m_system->playSound(FMOD_CHANNEL_REUSE, m_sound, false, &m_coolSoundChannel);
        }
    }  
  else
  {
     // The sound hasn't been played yet... this will play it and pick a free channel and assign it to m_coolSoundChannel
     m_system->playSound(FMOD_CHANNEL_FREE, m_sound, false, &m_coolSoundChannel);
  }
}
void GameSound::Stop()
{
  if(m_coolSoundChannel != NULL)
  {
        // If we are here, then we have played the sound at least once... lets check to see if it is currently playing
	  m_coolSoundChannel->stop();
  }
 
}



