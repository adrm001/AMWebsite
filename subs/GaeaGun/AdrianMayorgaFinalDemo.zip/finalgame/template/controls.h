
#ifndef CONTROLS_H
#define CONTROLS_H

// The main G3D header
#include <G3DAll.h>

class	CApp;


class CControls : public GApplet {
public:

					CControls(CApp	*app);
	virtual			~CControls();

					// The following functions are called to do specific actions
	virtual void	onInit();
	virtual void	onLogic();
	virtual void	onNetwork();
	virtual void	onSimulation(RealTime rdt, SimTime sdt, SimTime idt);
	virtual void	onGraphics(RenderDevice* rd);
	virtual void	onUserInput(UserInput* ui);
	virtual void	onCleanup();

protected:
					// Pointer to the application so we can access the global data
	CApp			*app;

					// A texture we use for this template
	TextureRef		texture;
	float rot;
};


#endif




