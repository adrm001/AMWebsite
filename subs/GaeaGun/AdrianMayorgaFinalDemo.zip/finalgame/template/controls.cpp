///////////////////////////////////////////////////////////////////////
//
//  File				:	Controls.cpp
//  Classes				:	CControls
//  Description			:	The implementation for the CControls class
//
////////////////////////////////////////////////////////////////////////
//#include "controls.h"
#include "application.h"



///////////////////////////////////////////////////////////////////////
// Class				:	CControls
// Method				:	CControls
// Description			:	Ctor
// Return Value			:	-
// Comments				:
CControls::CControls(CApp	*app) : GApplet(app) {

	// Save the application pointer
	this->app		=	app;
	this->texture	=	Texture::fromFile(app->dataDir + "/image/rules.jpg");
}


///////////////////////////////////////////////////////////////////////
// Class				:	CControls
// Method				:	~CControls
// Description			:	Dtor
// Return Value			:	-
// Comments				:
CControls::~CControls() {

	// Nothing to do here
}


///////////////////////////////////////////////////////////////////////
// Class				:	CControls
// Method				:	onInit
// Description			:	Put your code that does the applet specific initialization
// Return Value			:	-
// Comments				:
void CControls::onInit() { 

	// Initialize the camera
	app->debugCamera.setPosition(Vector3(0,0,-10));
	app->debugCamera.lookAt(Vector3(0,0,0));
	rot=0;
}


///////////////////////////////////////////////////////////////////////
// Class				:	CControls
// Method				:	onLogic
// Description			:	Put the logic code (AI etc.) here
// Return Value			:	-
// Comments				:
void CControls::onLogic() {

	// No logic yet
	rot+=.005;
}


///////////////////////////////////////////////////////////////////////
// Class				:	CControls
// Method				:	onNetwork
// Description			:	Put your network code here
// Return Value			:	-
// Comments				:
void CControls::onNetwork() { 

	// No network
}


///////////////////////////////////////////////////////////////////////
// Class				:	CControls
// Method				:	onSimulation
// Description			:	Put your physics related code here
// Return Value			:	-
// Comments				:
void CControls::onSimulation(RealTime rdt, SimTime sdt, SimTime idt) { 
}


///////////////////////////////////////////////////////////////////////
// Class				:	CControls
// Method				:	onGraphics
// Description			:	Put the drawing code here
// Return Value			:	-
// Comments				:
void CControls::onGraphics(RenderDevice* rd) { 

	
	// Set the background color to black
	rd->setColorClearValue(Color3(0.0f, 0.0f, 0.0f));

	// Clear the color/depth buffer
	rd->clear(true, true, true);

	// Draw a square ground, 100 units in x and z
	rd->setColor(Color3::white());	// The color is white
	rd->setTexture(0,texture);		// And it is textured
	rd->push2D();
	//*app->debugFont->draw2D("CONTROLS",		Vector2(200, 10), 65, Color3::white(),Color3::black());

		rd->beginPrimitive(RenderDevice::QUADS);
			rd->setColor(Color3::white());
			rd->setTexCoord(0,Vector2(0,0));
			rd->sendVertex(Vector2(0,0));
			rd->setTexCoord(0,Vector2(1,0));
			rd->sendVertex(Vector2(800,0));
			rd->setTexCoord(0,Vector2(1,1));
			rd->sendVertex(Vector2(800,600));
			rd->setTexCoord(0,Vector2(0,1));
			rd->sendVertex(Vector2(0,600));
		rd->endPrimitive();
		/*
	app->debugFont->draw2D("Press tab to enable camera movement,use WASD-mouse to control",	Vector2(30, 150), 10, Color3::white(),Color4::clear());
	app->debugFont->draw2D("TFGH will control tank movement. SHIFT toggles attack mode CTRL cycles your tanks",	Vector2(30, 200), 10, Color3::white(),Color4::clear());
	app->debugFont->draw2D("You have a limited amount of move points per turn, which can be distributed among your tanks",	Vector2(30, 250), 10, Color3::white(),Color4::clear());
	app->debugFont->draw2D("To shoot, turn on attack mode, aim, and press ENTER-this will end your turn",	Vector2(30, 300), 10, Color3::white(),Color4::clear());
	app->debugFont->draw2D("Press Esc or Left-Click to return to main menu",	Vector2(30, 550), 20, Color3::white(),Color3::gray());

*/
	
	rd->pop2D();
}


///////////////////////////////////////////////////////////////////////
// Class				:	CControls
// Method				:	onUserInput
// Description			:	Put your code that processes the user input here
// Return Value			:	-
// Comments				:
void CControls::onUserInput(UserInput* ui) { 

	// If the ESC key is pressed, quit the application
	if (ui->keyPressed(SDLK_ESCAPE)) {
        endApplet		= true;		// This will make the applet terminate
        app->runTitle();
    }
	if(ui->keyPressed(G3D::CustomKeyCode::SDL_LEFT_MOUSE_KEY))
	{
		endApplet		= true;
		app->runTitle();
	}

	// Add other key handling here
}


///////////////////////////////////////////////////////////////////////
// Class				:	CControls
// Method				:	onCleanup
// Description			:	Put your code that cleans up the applet here
// Return Value			:	-
// Comments				:
void CControls::onCleanup() { 
}

