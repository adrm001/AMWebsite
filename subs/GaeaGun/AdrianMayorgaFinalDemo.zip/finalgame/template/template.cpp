///////////////////////////////////////////////////////////////////////
//
//  File				:	template.cpp
//  Classes				:	CTemplate
//  Description			:	The implementation for the CTemplate class
//
////////////////////////////////////////////////////////////////////////

#include "application.h"



///////////////////////////////////////////////////////////////////////
// Class				:	CTemplate
// Method				:	CTemplate
// Description			:	Ctor
// Return Value			:	-
// Comments				:
CTemplate::CTemplate(CApp	*app) : GApplet(app) {

	// Save the application pointer
	this->app		=	app;
	this->texture	=	Texture::fromFile(app->dataDir + "/image/gaeagun.jpg");
	this->play		=	Color3::yellow();
	this->controls	=	Color3::gray();
	this->quit		=	Color3::gray();
	this->mY		=	0.0f;
}


///////////////////////////////////////////////////////////////////////
// Class				:	CTemplate
// Method				:	~CTemplate
// Description			:	Dtor
// Return Value			:	-
// Comments				:
CTemplate::~CTemplate() {

	// Nothing to do here
}


///////////////////////////////////////////////////////////////////////
// Class				:	CTemplate
// Method				:	onInit
// Description			:	Put your code that does the applet specific initialization
// Return Value			:	-
// Comments				:
void CTemplate::onInit() { 

	// Initialize the camera
	app->debugCamera.setPosition(Vector3(0,50,0));
	app->debugCamera.lookAt(Vector3(0,0,0));
}


///////////////////////////////////////////////////////////////////////
// Class				:	CTemplate
// Method				:	onLogic
// Description			:	Put the logic code (AI etc.) here
// Return Value			:	-
// Comments				:
void CTemplate::onLogic() {

	// No logic yet
}


///////////////////////////////////////////////////////////////////////
// Class				:	CTemplate
// Method				:	onNetwork
// Description			:	Put your network code here
// Return Value			:	-
// Comments				:
void CTemplate::onNetwork() { 

	// No network
}


///////////////////////////////////////////////////////////////////////
// Class				:	CTemplate
// Method				:	onSimulation
// Description			:	Put your physics related code here
// Return Value			:	-
// Comments				:
void CTemplate::onSimulation(RealTime rdt, SimTime sdt, SimTime idt) { 
}


///////////////////////////////////////////////////////////////////////
// Class				:	CTemplate
// Method				:	onGraphics
// Description			:	Put the drawing code here
// Return Value			:	-
// Comments				:
void CTemplate::onGraphics(RenderDevice* rd) { 

	// Copy the camera from the debug camera
	rd->setProjectionAndCameraMatrix(app->debugCamera);

	// Set the background color to black
	rd->setColorClearValue(Color3(0.0f, 0.0f, 0.0f));

	// Clear the color/depth buffer
	rd->clear(true, true, true);

	// Draw a square ground, 100 units in x and z
	rd->setColor(Color3::white());	// The color is white
	rd->setTexture(0,texture);		// And it is textured
	rd->push2D();
		rd->pushState();
		rd->setObjectToWorldMatrix(CoordinateFrame(Vector3(150,50,0)));
		rd->beginPrimitive(RenderDevice::QUADS);
			rd->setColor(Color3::white());
			rd->setTexCoord(0,Vector2(0,0));
			rd->sendVertex(Vector2(0,0));
			rd->setTexCoord(0,Vector2(1,0));
			rd->sendVertex(Vector2(500,0));
			rd->setTexCoord(0,Vector2(1,1));
			rd->sendVertex(Vector2(500,150));
			rd->setTexCoord(0,Vector2(0,1));
			rd->sendVertex(Vector2(0,150));
		rd->endPrimitive();
		rd->popState();
		app->debugFont->draw2D("PLAY",		Vector2(300, 200), 60, Color3::white(), play);
		app->debugFont->draw2D("RULES",	Vector2(300, 300), 60, Color3::white(), controls);
		app->debugFont->draw2D("QUIT",		Vector2(300, 400), 60, Color3::white(), quit);

	
	rd->pop2D();

	// Begin drawing the quad
    /*rd->beginPrimitive(RenderDevice::QUADS);

		// First vertex
		rd->setTexCoord(0,Vector2(0,0));
        rd->sendVertex(Vector3(-50,	0, 50));

		// Second
		rd->setTexCoord(0,Vector2(0,1));
        rd->sendVertex(Vector3(50,	0, 50));

		// Third
		rd->setTexCoord(0,Vector2(1,1));
        rd->sendVertex(Vector3(50,	0, -50));

		// Fourth
		rd->setTexCoord(0,Vector2(1,0));
        rd->sendVertex(Vector3(-50,	0, -50));

    rd->endPrimitive();*/

	// Display a text at the top left corner
	
}


///////////////////////////////////////////////////////////////////////
// Class				:	CTemplate
// Method				:	onUserInput
// Description			:	Put your code that processes the user input here
// Return Value			:	-
// Comments				:
void CTemplate::onUserInput(UserInput* ui) { 

	if(ui->keyPressed(SDLK_UP))
	{
		if(play==Color3::yellow())
		{
			play		=	Color3::gray();
			controls	=	Color3::gray();
			quit		=	Color3::yellow();
		}else if(controls==Color3::yellow())
		{
			play		=	Color3::yellow();
			controls	=	Color3::gray();
			quit		=	Color3::gray();
		}else{
			play		=	Color3::gray();
			controls	=	Color3::yellow();
			quit		=	Color3::gray();
		}
	}
	if(ui->keyPressed(SDLK_DOWN))
	{
		if(play==Color3::yellow())
		{
			play		=	Color3::gray();
			controls	=	Color3::yellow();
			quit		=	Color3::gray();
		}else if(controls==Color3::yellow())
		{
			play		=	Color3::gray();
			controls	=	Color3::gray();
			quit		=	Color3::yellow();
		}else{
			play		=	Color3::yellow();
			controls	=	Color3::gray();
			quit		=	Color3::gray();
		}
	}

	
	if(G3D::abs(mY-ui->mouseXY().y)>5)
	{
		mY=ui->getMouseXY().y;
		if(mY>=200&&mY<300)
		{
			play		=	Color3::yellow();
			controls	=	Color3::gray();
			quit		=	Color3::gray();
			}
		if (mY>=300&&mY<400)
		{
			play		=	Color3::gray();
			controls	=	Color3::yellow();
			quit		=	Color3::gray();
			}if (mY>=400&&mY<500)
		{
			play		=	Color3::gray();
			controls	=	Color3::gray();
			quit		=	Color3::yellow();
		
		}
	}
	if(ui->keyPressed(G3D::CustomKeyCode::SDL_LEFT_MOUSE_KEY)||ui->keyPressed(SDLK_RETURN))
	{
		
		if(play == Color3::yellow())
		{endApplet= true;app->runPlay();}
		else if(controls == Color3::yellow())
		{endApplet= true;app->runControls();}
		else if(quit == Color3::yellow())
		{endApplet= true;app->endProgram=true;}
	}

	
	
}


///////////////////////////////////////////////////////////////////////
// Class				:	CTemplate
// Method				:	onCleanup
// Description			:	Put your code that cleans up the applet here
// Return Value			:	-
// Comments				:
void CTemplate::onCleanup() { 
}

