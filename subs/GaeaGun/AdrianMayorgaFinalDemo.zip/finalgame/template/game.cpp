///////////////////////////////////////////////////////////////////////
//
//  File				:	game.cpp
//  Classes				:	Cgame
//  Description			:	The implementation for the Cgame class
//
////////////////////////////////////////////////////////////////////////
#include "game.h"
#include "application.h"


using namespace std;

///////////////////////////////////////////////////////////////////////
// Class				:	Cgame
// Method				:	Cgame
// Description			:	Ctor
// Return Value			:	-
// Comments				:
Cgame::Cgame(CApp	*app) : GApplet(app) {

	// Save the application pointer
	this->app		=	app;
	this->texture	=	Texture::fromFile(app->dataDir + "/image/floor1.jpg");
//	texture->
	scene = Scene(texture,GFont::fromFile(app->dataDir + "/font/dominant.fnt"),this);

}


///////////////////////////////////////////////////////////////////////
// Class				:	Cgame
// Method				:	~Cgame
// Description			:	Dtor
// Return Value			:	-
// Comments				:
Cgame::~Cgame() {

	// Nothing to do here
}


///////////////////////////////////////////////////////////////////////
// Class				:	Cgame
// Method				:	onInit
// Description			:	Put your code that does the applet specific initialization
// Return Value			:	-
// Comments				:
void Cgame::onInit() { 

	// Initialize the camera
	app->debugCamera.setPosition(Vector3(35,30,-2));
	app->debugCamera.lookAt(Vector3(3,0,30));
	sky = Sky::fromFile(app->renderDevice, app->dataDir + "sky/");
	time= toSeconds(12,0,AM);
	accum=0;
	//mesh.setAnimatePush(true);
}


///////////////////////////////////////////////////////////////////////
// Class				:	Cgame
// Method				:	onLogic
// Description			:	Put the logic code (AI etc.) here
// Return Value			:	-
// Comments				:
void Cgame::onLogic() {

	// No logic yet
//	time+=100;
//	mesh.updateAni();
}


///////////////////////////////////////////////////////////////////////
// Class				:	Cgame
// Method				:	onNetwork
// Description			:	Put your network code here
// Return Value			:	-
// Comments				:
void Cgame::onNetwork() { 

	// No network
}


///////////////////////////////////////////////////////////////////////
// Class				:	Cgame
// Method				:	onSimulation
// Description			:	Put your physics related code here
// Return Value			:	-
// Comments				:
void Cgame::onSimulation(RealTime rdt, SimTime sdt, SimTime idt) { 

	accum+=rdt;
	for(;accum>0;accum-=.005)
	{
		scene.update(.005);
	}
	scene.endupdate();
}


///////////////////////////////////////////////////////////////////////
// Class				:	Cgame
// Method				:	onGraphics
// Description			:	Put the drawing code here
// Return Value			:	-
// Comments				:
void Cgame::onGraphics(RenderDevice* rd) { 

	LightingParameters lighting(time);
	
	
	// Copy the camera from the debug camera
	rd->setProjectionAndCameraMatrix(scene.camera);
	//rd->setProjectionAndCameraMatrix(app->debugCamera);
	
	rd->setLight(1,GLight::directional(Vector3(1,1,1),Color3::white()));
	
	// Set the background color to black
	rd->setColorClearValue(Color3(0.0f, 0.0f, 0.0f));
	rd->setAlphaWrite(true);
	// Clear the color/depth buffer
	rd->clear(true, true, true);
	sky->render(rd,lighting);

	rd->enableLighting();
	//rd->setLight(0,GLight::point(Vector3(5,10,5),Color3::white(),1,0,0,false,true));
	
	rd->setShadeMode(RenderDevice::SHADE_SMOOTH);
	/*GLfloat fogColor[4]= {0.0f, 0.0f, 0.0f, 1.0f};
		glFogi(GL_FOG_MODE,GL_LINEAR);
		glFogfv(GL_FOG_COLOR, fogColor);			// Set Fog Color
		glFogf(GL_FOG_DENSITY, 0.35f);				// How Dense Will The Fog Be
		glHint(GL_FOG_HINT, GL_DONT_CARE);			// Fog Hint Value
		glFogf(GL_FOG_START,20.0f);				// Fog Start Depth
		glFogf(GL_FOG_END,2500.0f);				// Fog End Depth
		glEnable(GL_FOG);*/

	
		
	scene.render(rd);
		

}


///////////////////////////////////////////////////////////////////////
// Class				:	Cgame
// Method				:	onUserInput
// Description			:	Put your code that processes the user input here
// Return Value			:	-
// Comments				:
void Cgame::onUserInput(UserInput* ui) { 

	// If the ESC key is pressed, quit the application
	if (ui->keyPressed(SDLK_ESCAPE)) {
        endApplet		= true;		// This will make the applet terminate
		scene.cleanUP();
		app->runTitle();	
    }
	if(ui->keyPressed('w')||ui->keyDown('w')||ui->keyPressed(SDLK_UP)||ui->keyDown(SDLK_UP))
		scene.upDown(5);
	if(ui->keyPressed('a')||ui->keyDown('a')||ui->keyPressed(SDLK_LEFT)||ui->keyDown(SDLK_LEFT))
		scene.rotateLeft(1);
	if(ui->keyPressed('s')||ui->keyDown('s')||ui->keyPressed(SDLK_DOWN)||ui->keyDown(SDLK_DOWN))
		scene.upDown(-5);
	if(ui->keyPressed('d')||ui->keyDown('d')||ui->keyPressed(SDLK_RIGHT)||ui->keyDown(SDLK_RIGHT))
		scene.rotateRight(1);
	if(ui->keyPressed(' '))
		scene.PRESS();
	if(ui->keyReleased(' '))
		scene.REALSE();
	if(ui->keyPressed(SDLK_LALT)||ui->keyPressed(SDLK_RALT))
		scene.cycleWep();


	if(ui->keyPressed(SDLK_LSHIFT))
		scene.switchMode();
//	if(ui->keyPressed(SDLK_RETURN))
//		scene.shoot();
	if(ui->keyPressed(SDLK_TAB))
		scene.cycleTanks();
	if(ui->keyPressed(SDLK_LCTRL))
		scene.cycleCam();
	if(ui->keyPressed('-')||ui->keyDown('-'))
		scene.zoom(0.5f);
	if(ui->keyPressed('=')||ui->keyDown('='))
		scene.zoom(-0.5f);



	if(ui->keyPressed(' '))
	{	
		scene.cleanUP();
		if(scene.getOVER())
		{
			app->runTitle();
			this->endApplet=true;
		}
	}

	/*if(ui->keyPressed(' '))
		scene.mesh->kill();
	if(ui->keyDown('u'))
		scene.mesh->moveKil(Vector3(0,1,0));
	if(ui->keyDown('o'))
		scene.mesh->moveKil(Vector3(0,-1,0));
	if(ui->keyDown('l'))
		scene.mesh->moveKil(Vector3(1,0,0));
	if(ui->keyDown('j'))
		scene.mesh->moveKil(Vector3(-1,0,0));
	if(ui->keyDown('k'))
		scene.mesh->moveKil(Vector3(0,0,1));
	if(ui->keyDown('i'))
		scene.mesh->moveKil(Vector3(0,0,-1));*/
}


///////////////////////////////////////////////////////////////////////
// Class				:	Cgame
// Method				:	onCleanup
// Description			:	Put your code that cleans up the applet here
// Return Value			:	-
// Comments				:
void Cgame::onCleanup() { 
}

