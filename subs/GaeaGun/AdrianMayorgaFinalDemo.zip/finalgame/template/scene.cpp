#include "game.h"


void drawSphere(RenderDevice *rd,float rrr=1.0f,Vector3 cent=Vector3(0,0,0));
void drawLaser(RenderDevice *rd);
using namespace G3D;
Scene::Scene(G3D::TextureRef f,GFontRef fn,Cgame *g)
{
	this->dim=4;
	this->mesh = new Mesh(f,dim);
	this->camera = GCamera();
	this->debug = false;
	this->bullet.append(0);
	//srand(System::getCycleCount());
	this->players.append(Player(3,Color3::red(),mesh,dim));
	this->players.append(Player(3,Color3::blue(),mesh,dim));
	this->current_player =0;
	this->ctank = players[0].tanks[players[0].current_tank];
	ctank->flipCurrent();
	this->font = fn;
	gameOVER=false;
	camera.setPosition(Vector3(35,30,-150));
	camera.lookAt(Vector3(3,0,30));
	GCamera tempy;
	tempy.setPosition(Vector3(35,30,150));
	tempy.lookAt(Vector3(3,0,30));
	curCamFrame=camera.getCoordinateFrame();
	tarCamFrame=tempy.getCoordinateFrame();
	first=true;
	this->camTrans=1000;
	this->game=g;
	this->power=0;
	this->press=false;
	
	
}

void drawSphere(RenderDevice *rd,float rrr,Vector3 cent)
{
	int pre = 10;//preccision
	float pp = (float)pre;
	//rd->setTexture(0,texture);
	float radius =rrr;
	for(int i=0;i<pre/2;i++)
	{
		double angle1	=	 i*twoPi()/pp + halfPi();
		double angle2	=	(i + 1)*twoPi()/pp + halfPi();
		
		rd->beginPrimitive(RenderDevice::QUAD_STRIP);
		//glBegin(GL_QUAD_STRIP);
		for(int j = 0;j<=pre;j++)
		{
			double angle3	=	j*twoPi()/pp;
			Vector3	normal(1.0*cos(angle2)*cos(angle3),1.0*sin(angle2),1.0*cos(angle2)*sin(angle3));
			Vector3 point(radius*normal.x,radius*normal.y,radius*normal.z);
			rd->setNormal(normal);
		//	glNormal(normal);
			rd->setTexCoord(3,Vector2(1.0-j/pp,2.0*(i+1)/pp));
		//	glTexCoord(Vector2(1.0-j/pp,2.0*(i+1)/pp));
			rd->sendVertex(point+cent);
		//	glVertex(point);
			normal	=	Vector3(1.0*cos(angle1)*cos(angle3),1.0*sin(angle1),1.0*cos(angle1)*sin(angle3));
			point	=	Vector3(radius*normal.x,radius*normal.y,radius*normal.z);
			rd->setNormal(normal);
		//	glNormal(normal);
			rd->setTexCoord(3,Vector2(1.0-j/pp,2.0*i/pp));
		//	glTexCoord(Vector2(1.0-j/pp,2.0*i/pp));
			rd->sendVertex(point+cent);
		//	glVertex(point);
		}
		rd->endPrimitive();
		//glEnd();
	}
}
void drawLaser(RenderDevice *rd)
{
//	rd->setTexture(3,NULL);
	//
//	rd->pushState();
//	rd->disableLighting();
//	rd->setTexture(3,NULL);
	float radd=.05f;
	Capsule cap(Vector3(0,0,0),Vector3(0,0,-.5),radd);
//	rd->setBlendFunc(RenderDevice::BlendFunc::BLEND_SRC_ALPHA,
//						 RenderDevice::BlendFunc::BLEND_ONE_MINUS_SRC_ALPHA,
//						 RenderDevice::BlendEq::BLENDEQ_ADD);
//	rd->disableDepthWrite();
	//rd->setColor(Color4(0,1,1,.5));
	drawSphere(rd,radd,cap.getPoint1());

	drawSphere(rd,radd,cap.getPoint2());
	drawSphere(rd,radd,cap.getPoint1().lerp(cap.getPoint2(),.25));
	drawSphere(rd,radd,cap.getPoint1().lerp(cap.getPoint2(),.75));
	drawSphere(rd,radd,cap.getPoint1().lerp(cap.getPoint2(),.50));




//	rd->enableLighting();
//	rd->enableDepthWrite();
	//
//	rd->popState();
}
void Scene::render(G3D::RenderDevice *rd)
{
	if(!gameOVER)
	{
		

		
		rd->setLight(0,GLight::point(curCamFrame.translation,Color3::white(),0,.1,0,false,true));
		//rd->setProjectionAndCameraMatrix(camera);
			rd->setColor(Color3::red());
		rd->disableLighting();
		rd->beginPrimitive(RenderDevice::QUADS);
		
		rd->setTexCoord(3,Vector2(0,0));
		rd->sendVertex(Vector3(-1000,2.5,-1000));

		rd->setTexCoord(3,Vector2(0,10));
		rd->sendVertex(Vector3(-1000,2.5,1000));

		rd->setTexCoord(3,Vector2(10,10));
		rd->sendVertex(Vector3(1000,2.5,1000));

		rd->setTexCoord(3,Vector2(10,0));
		rd->sendVertex(Vector3(1000,2.5,-1000));
		
		rd->endPrimitive();
		rd->enableLighting();
		mesh->render(rd,&camera);
	
		
		for(int i=0;i<players.size();i++)
			for(int j=0;j<players[i].tanks.size();j++)
			{
				Tank *tank = players[i].tanks[j]; 
				tank->render(rd);
			}

		if(bullet[0]!=0)
		{
			bullet[0]->render(rd);
		}
		
		rd->setTexture(3,NULL);
		rd->setShininess(0);
		rd->setSpecularCoefficient(0);
		rd->push2D();
		font->draw2D(rd,"Move Points:",Vector2(300,10),20,Color3::white(),Color4::clear());
		font->draw2D(rd,"Health`Points:",Vector2(300,50),20,Color3::white(),Color4::clear());
			
			rd->beginPrimitive(RenderDevice::QUADS);
				rd->setColor(Color3::green());

				rd->sendVertex(Vector2(420,20));
				rd->sendVertex(Vector2(420,35));
				rd->sendVertex(Vector2(420+/*players[current_player].*/ctank->moved*3,35));
				rd->sendVertex(Vector2(420+/*players[current_player].*/ctank->moved*3,20));
			
				rd->sendVertex(Vector2(420,60));
				rd->sendVertex(Vector2(420,75));
				rd->sendVertex(Vector2(420+/*players[current_player].*/ctank->getHealth(),75));
				rd->sendVertex(Vector2(420+/*players[current_player].*/ctank->getHealth(),60));
			rd->endPrimitive();
		if(current_player==0)
		{
			font->draw2D(rd,">",Vector2(10,10),20,Color3::white(),Color3::white());
		}
		else
		{
			font->draw2D(rd,">",Vector2(10,40),20,Color3::white(),Color3::white());
			font->draw2D(rd,"Move Points:",Vector2(300,10),20,Color3::white(),Color4::clear());
		}
		font->draw2D(rd,"Player1",Vector2(30,10),20,Color3::red(),Color3::orange());
		font->draw2D(rd,"Player2",Vector2(30,40),20,Color3::blue(),Color3::green());
		rd->beginPrimitive(RenderDevice::QUADS);
			rd->setColor(Color3::green());

			rd->sendVertex(Vector2(110,20));
			rd->sendVertex(Vector2(110,35));
			rd->sendVertex(Vector2(110+players[0].totallife/3,35));
			rd->sendVertex(Vector2(110+players[0].totallife/3,20));

			rd->sendVertex(Vector2(110,50));
			rd->sendVertex(Vector2(110,65));
			rd->sendVertex(Vector2(110+players[1].totallife/3,65));
			rd->sendVertex(Vector2(110+players[1].totallife/3,50));

			if(ctank->getShotMode())
			{
				rd->setColor(Color3::gray());

				rd->sendVertex(Vector2(210,550));
				rd->sendVertex(Vector2(210,565));
				rd->sendVertex(Vector2(210+100*5,565));
				rd->sendVertex(Vector2(210+100*5,550));
			}

			rd->setColor(Color3::red());

			rd->sendVertex(Vector2(210,550));
			rd->sendVertex(Vector2(210,565));
			rd->sendVertex(Vector2(210+power*5,565));
			rd->sendVertex(Vector2(210+power*5,550));
			
		
		rd->endPrimitive();
		
		rd->disableLighting();
		rd->disableDepthWrite();
		rd->setBlendFunc(RenderDevice::BlendFunc::BLEND_SRC_ALPHA,
						 RenderDevice::BlendFunc::BLEND_ONE_MINUS_SRC_ALPHA,
						 RenderDevice::BlendEq::BLENDEQ_ADD);
		rd->setTexture(3,NULL);
		rd->beginPrimitive(RenderDevice::TRIANGLE_FAN);
		rd->setColor(Color4(0.0f,1.0f,.5f,.25f));
		Vector2 radcenter(100,500);
		rd->sendVertex(radcenter);
		for(float j=twoPi();j>=-twoPi()/40;j-=(twoPi()/40))
		{
			rd->sendVertex(Vector2(cos(j)*90,sin(j)*90)+radcenter);
		}
		rd->endPrimitive();
		rd->setLineWidth(3);
		rd->beginPrimitive(RenderDevice::LINE_STRIP);
		rd->setColor(Color4(1.0f,1.0f,1.0f,1.0f));
		for(float j=twoPi();j>=-twoPi()/40;j-=(twoPi()/40))
		{
			rd->sendVertex(Vector2(cos(j)*90,sin(j)*90)+radcenter);
		}
		rd->endPrimitive();
		rd->beginPrimitive(RenderDevice::LINE_STRIP);
		for(float j=twoPi();j>=-twoPi()/40;j-=(twoPi()/40))
		{
			rd->sendVertex(Vector2(cos(j)*60,sin(j)*60)+radcenter);
		}
		rd->endPrimitive();
		rd->beginPrimitive(RenderDevice::LINE_STRIP);
		for(float j=twoPi();j>=-twoPi()/40;j-=(twoPi()/40))
		{
			rd->sendVertex(Vector2(cos(j)*30,sin(j)*30)+radcenter);
		}
		rd->endPrimitive();
		rd->beginPrimitive(RenderDevice::LINES);
		rd->sendVertex(Vector2(-90,0)+radcenter);
		rd->sendVertex(Vector2(90,0)+radcenter);
		rd->sendVertex(Vector2(0,-90)+radcenter);
		rd->sendVertex(Vector2(0,90)+radcenter);
		rd->endPrimitive();

		rd->setPointSize(5);
		rd->beginPrimitive(RenderDevice::POINTS);
		for(int i=0;i<radarTanks.size();i++)
		{
			rd->setColor(radarColor[i]);
			rd->sendVertex(radarTanks[i]*3+radcenter);
		}
		rd->endPrimitive();
		rd->pop2D();
	}
	else
	{
		rd->push2D();
			font->draw2D(rd,"GAME OVER!!",Vector2(300,300),40,Color3::white(),Color4::clear());
		if(winner ==0)
			font->draw2D(rd,"Player1 Wins",Vector2(300,400),30,Color3::white(),Color4::clear());
		else
			font->draw2D(rd,"Player2 Wins",Vector2(300,400),30,Color3::white(),Color4::clear());
		
		font->draw2D(rd,"Press space to go back to menu",Vector2(300,460),20,Color3::white(),Color4::clear());
		rd->pop2D();
	}
	if(first)
	{
		rd->setColor(Color3::green());
		rd->pushState();
		glNewList(1,GL_COMPILE);
		drawSphere(rd);
		glEndList();
		rd->popState();
		rd->pushState();
		glNewList(2,GL_COMPILE);
		drawLaser(rd);
		glEndList();
		rd->popState();
		first=false;
	}
	/*else
	{
		rd->pushState();
		rd->setColor(Color3::blue());
		rd->setObjectToWorldMatrix(CoordinateFrame(Matrix3::identity()*3));
		glCallList(1);
		rd->popState();
	}*/
}

void Scene::cleanUP()
{
	if(gameOVER)
	{
		mesh->cleanUP();
		gameOVER=true;
	}
}
void Scene::upDown(float num)
{
	if(!gameOVER)
	{
		if(ctank->getShotMode())
			ctank->angle(num*.1);
		else
		{
			ctank->movez(-num);
		}
		tarCamFrame=ctank->getCamFrame();
		this->camTrans=1000;
	}
}

void Scene::movez(float zd)
{
	if(!gameOVER)
	{
		ctank->movez(zd);
		tarCamFrame=ctank->getCamFrame();
		this->camTrans=1000;
	}
}
void Scene::switchMode()
{
	if(!gameOVER)
	{
		ctank->setShotMode(!ctank->getShotMode());
		tarCamFrame=ctank->getCamFrame();
		this->camTrans=1000;
	}
}

void Scene::rotateLeft(float rt)
{
	if(!gameOVER)
	{
		ctank->rotate(rt);
		tarCamFrame=ctank->getCamFrame();
		this->camTrans=1000;
	}

}
void Scene::rotateRight(float rt)
{
	if(!gameOVER)
	{
		ctank->rotate(-rt);
		tarCamFrame=ctank->getCamFrame();
		this->camTrans=1000;
	}

}
void Scene::shoot(float p)
{
	if(!gameOVER)
	{
		if(ctank->getShotMode())
		{
			if(bullet[0]!=0)
				delete bullet[0];
			bullet[0]=ctank->getShotStart(p);
		}
	}
}
void Scene::calcRad()
{
	this->radarColor.fastClear();
	this->radarTanks.fastClear();

	Vector2 targ=curCamFrame.translation.xz();
	Vector3 ang=curCamFrame.lookVector();
	if(ctank->getCamMode()==2)
	{
		targ=targ+(ctank->getPos().xz()-tarCamFrame.translation.xz());
	}
	if(ctank->getCamMode()==0)
	{
		ang=curCamFrame.upVector();
	}
	CoordinateFrame lookframe(Vector3(targ.x,curCamFrame.translation.y,targ.y));
	lookframe.lookAt(ang+lookframe.translation,Vector3(0,1,0));
	for(int i=0;i<players.size();i++)
	{
		for(int k=0;k<players[i].tanks.size();k++)
		{
			Vector2 tempvec2 = players[i].tanks[k]->getPos().xz()-targ;
			float dist=tempvec2.length();
			if(dist<=30)
			{
				radarTanks.append(lookframe.pointToObjectSpace(players[i].tanks[k]->getPos()).xz());
				radarColor.append(players[i].color);
			}
		}
	}
}
void Scene::update(RealTime time)
{
	if(!gameOVER)
	{
		mesh->update(time);
		if(press)
		{
			power+=time*50;
			if(power>100)
				power=100;
		}
		if(!(curCamFrame.fuzzyEq(tarCamFrame)))
		{
			curCamFrame = curCamFrame.lerp(tarCamFrame,.02f);
			camera.setCoordinateFrame(curCamFrame);
			camTrans--;
			if(camTrans<0)
				curCamFrame=tarCamFrame;
			calcRad();
		}
		

		for(int i=0;i<players.size();i++)
		{
			for(int j=0;j<players[i].tanks.size();j++)
			{
				Tank *tank = players[i].tanks[j]; 
				Vector3 result;
				bool testSur =(tank->getPos().y<20&&mesh->valueAt(tank->getPos())>=-0.001);//mesh->onSurface(tank->getPos()); 
				if(!(testSur))
					tank->addForce(Vector3(0,-10,0));
				
				Vector3 thrust = tank->getThrustForce();

				if(ctank->/*players[i].*/moved<=0)
					thrust=Vector3::zero();
				//tank->setVel(tank->getVel()+thrust);

				if(testSur&&(thrust!=Vector3::zero())&&mesh->valueAt(tank->getPos())<=.05f)
				{
					/*players[i].*/ctank->moved-=thrust.magnitude()*time*10;
					Vector3 reslt;
					Vector3 pv0 = tank->getPos() + thrust*time;
					bool success = mesh->toSurface(pv0 + tank->getNormal()*.1f,pv0 - tank->getNormal()*.1f,reslt);
					if(success)
					{	
						tank->setPoint(reslt);
						tank->fixNormal(mesh->normalAt(reslt));

					}			
				}
				else
				{
					if(mesh->intersect(tank,result,time))
					{	
						tank->setPoint(result);
						Vector3 nor = mesh->normalAt(result);
						tank->fixNormal(nor);
						
						
						Vector3 newTh = thrust - nor*nor.dot(thrust);
						tank->setVel(newTh);
					}else
					{
						if(testSur)
						{
							tank->addForce(tank->getFrame().vectorToWorldSpace(Vector3(0,1,0)));
							tank->setVel(Vector3(0,0,0)); //for now do this, snap to sruface later
						}
					}
				}

				tank->update(time);
				if(tank->alive())
				{
					Vector3 nor = mesh->normalAt(tank->getPos());
					if(nor.isFinite())
						tank->fixNormal(nor);

					tank->setPoint(fixBound(tank->getPos()));
				}else
				{
					/*if(!tank->exploded)
					{
						Particle *temppar=new Particle(tank->getPos(),Vector3(0,0,0),mesh);
						temppar->setGo(true);
						temppar->setInter(tank->getPos());
						
						int indx=1;
						bool contser=true;
						while(contser&&indx<bullet.size())
						{
							if(bullet[indx]==0)
								contser=false;
							indx++;
						}
						if(indx>=bullet.size())
						{
							bullet.append(temppar);
						}else
						{
							bullet[indx]=temppar;
						}
						tank->exploded=true;
					}*/
				}
			}
		}
		if(!ctank->alive())
		{
			ctank->flipCurrent();
			for(int i=0;i<players.size();i++)
			{
				players[i].removeDead();
			}
			nextPlayer();
			if(!gameOVER)
			{
				ctank = players[current_player].tanks[players[current_player].current_tank];
				ctank->flipCurrent();
				players[current_player].moved=100;
				for(int w=0;w<players[current_player].tanks.size();w++)
				{
					players[current_player].tanks[w]->moved=100;
				}
				tarCamFrame=ctank->getCamFrame();
				this->camTrans=1000;
			}
		}

		for(int q=0;q<bullet.size();q++)
		{
			if(bullet[q]!=0)
			{
				if(!bullet[q]->getGo())
				{
					bullet[q]->addForce(Vector3(0,-10,0));
					bullet[q]->update(time);
					Vector3 res;
					if(mesh->intersect(bullet[q],res,time))
					{
						bullet[q]->setGo(true);
						bullet[q]->setInter(res);
						
					}
					else
					{
						for(int i=0;i<players.size();i++)
						{
							for(int j=0;j<players[i].tanks.size();j++)
							{
								bullet[q]->intersect(players[i].tanks[j]);				
							}

						}
					}
				}
				else
				{
					bullet[q]->update(time);
					if(bullet[q]->getDeform()==1)
					{
						Sphere sphere(bullet[q]->getInter(),2);
						RealTime one = G3D::System::time();
						mesh->killAt(bullet[q]->getInter());
						one = G3D::System::time() - one;
						game->accum-=one;

					}

					if(bullet[q]->getAniEnd())
					{
						Sphere sphere(bullet[q]->getInter(),bullet[q]->getSphere());
			
						ctank->flipCurrent();
						for(int i=0;i<players.size();i++)
						{
							for(int j=0;j<players[i].tanks.size();j++)
							{
								if(sphere.contains(players[i].tanks[j]->getPos()))
								{
									players[i].tanks[j]->damage(40-((sphere.center-players[i].tanks[j]->getPos()).magnitude())*(15/2));
								}
							}
							players[i].removeDead();
						}
						nextPlayer();
						if(!gameOVER)
						{
							ctank = players[current_player].tanks[players[current_player].current_tank];
							ctank->flipCurrent();
							players[current_player].moved=100;
							for(int w=0;w<players[current_player].tanks.size();w++)
							{
								players[current_player].tanks[w]->moved=100;
							}
							tarCamFrame=ctank->getCamFrame();
							this->camTrans=1000;
						}
						delete bullet[q];
						bullet[q] = 0;
						
					}
				
				}
			}else
			{
				Array<int> countAlive;
				for(int i=0;i<players.size();i++)
				{
					players[i].removeDead();
					if(!(players[i].dead))
						countAlive.append(i);
				}
				if(countAlive.size()==1)
				{
					winner=countAlive[0];
					gameOVER=true;
				}
				if(countAlive.size()==0)
				{
					winner=-1;
					gameOVER=true;
				}

			}
		}
	}
}
void Scene::endupdate()
{
	if(!gameOVER)
	{
		for(int i=0;i<players.size();i++)
			for(int j=0;j<players[i].tanks.size();j++)
			{
				players[i].tanks[j]->resetStates();
			}
			
		ctank->makeProjection();
	}
}
void Scene::nextPlayer()
{
	int tempPlayer = current_player;
	do
	{
		current_player++;
		if(current_player>=players.size())
			current_player=0;
	}while(((players[current_player].dead))&&tempPlayer!=current_player);
	if(tempPlayer==current_player)
	{	
		if(!players[current_player].dead)
		{
			winner=tempPlayer;
		}
		else
			winner=-1;
		gameOVER=true;
	}
	this->calcRad();
	
}
const Vector3 Scene::fixBound(const Vector3 &p)
{
	Vector3 r=p;
	
	if(r.x<3)
		r.x=3;
	if(r.x>12*dim-3)
		r.x=12*dim-3;
	if(r.z<3)
		r.z=3;
	if(r.z>12*dim-3)
		r.z=12*dim-3;

	return r;
}
void Scene::cycleTanks()
{
	ctank->flipCurrent();
	players[current_player].cycleTanks();
	ctank = players[current_player].tanks[players[current_player].current_tank];
	tarCamFrame=ctank->getCamFrame();
	this->camTrans=1000;
	this->calcRad();
}
void Scene::cycleWep()
{
	ctank->cycleWep();
}
void Scene::cycleCam()
{
	ctank->cycleCam();
	tarCamFrame=ctank->getCamFrame();
	this->camTrans=1000;
	this->calcRad();
}
void Scene::zoom(float za)
{
	ctank->zoomCam(za);
	tarCamFrame=ctank->getCamFrame();
	this->camTrans=1000;
}
void Player::cycleTanks()
{
	this->current_tank++;
	if(current_tank>=tanks.size())
		current_tank=0;
	tanks[current_tank]->flipCurrent();
}
Player::Player(int numT,const G3D::Color3 &c,Mesh *m,int maxsiz)
{
	this->color=c;
	for(int i=0;i<numT;i++)
	{
		float randx=uniformRandom(10.0f,12.0f*maxsiz-10.f);
		float randz=uniformRandom(10.0f,12.0f*maxsiz-10.f);
		Vector3 pos(randx,25,randz);
		this->tanks.append(new Tank(pos,color,m));
		Vector3 pppp = tanks[i]->getPos();
		float dum=0;
	}
	this->totallife=numT*100;
	this->current_tank=0;
	moved=100;
	dead=false;
}
void Player::removeDead()
{
	Array<Tank*> newA;
	totallife=0;

	for(int i=0;i<tanks.size();i++)
	{
		if(tanks[i]->alive())
		{
			newA.append(tanks[i]);
			totallife+=tanks[i]->getHealth();
		}
		else
			delete tanks[i];

	}
	
	tanks=newA;
	if(this->current_tank>=tanks.size())
		current_tank=0;
	if(tanks.size()<=0)
		dead=true;
	
}
void Player::cleanUP()
{
	if(tanks.size()>0)
		tanks.deleteAll();
}