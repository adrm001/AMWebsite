#ifndef SCENE_H
#define SCENE_H

// The main G3D header
#include <G3DAll.h>
#include "mesh.h"

class Player;
class Cgame;

class Scene{
public:
	Scene(TextureRef f,GFontRef fn,Cgame *g);
	Scene(){}
	~Scene(){}

	void	render(RenderDevice *rd);


	
	void	rotateLeft(float rt);
	void	rotateRight(float rt);
	void	switchMode();
	void	cycleTanks();
	void	cycleCam();
	void	cycleWep();
	void	zoom(float za);

	void	upDown(float num);
	void	shoot(float p);

	void	update(RealTime time);
	const Vector3 fixBound(const Vector3 &p);
	void cleanUP();
	bool	getOVER(){return gameOVER;}
	bool debug;
	void endupdate();
	void PRESS(){if(!gameOVER&&ctank->getShotMode()){press=true;}}
	void REALSE(){press=false;shoot(power);power=0;}
	GCamera camera;
Mesh *mesh;
Tank *ctank;
private:

	void nextPlayer();
	void calcRad();
	void	movez(float zd);
	bool	gameOVER;

	bool first;
	int winner;
	int camTrans;
	float power;
	bool press;
	int dim;
	Array<Vector2> radarTanks;
	Array<Color3>  radarColor;
	
	
	
	CoordinateFrame curCamFrame;
	CoordinateFrame tarCamFrame;


	GFontRef font;
	Cgame *game;
	
	
	Array<Particle*>bullet;
	Array<Player> players;
	int current_player;


};
class Player
{
public:
	Player(){}
	~Player(){}
	Player(int numT,const Color3 &c,Mesh *m,int maxsiz);
	void cleanUP();
	void removeDead();
	Array<Tank*> tanks;
	Color3 color;
	int current_tank;
	float moved;
	float totallife;
	void cycleTanks();
	bool dead;

};


#endif