#ifndef PERLINGEN_H
#define PERLINGEN_H

// The main G3D header
#include <G3DAll.h>
class PerlinGen
{
public:
	static void scrambleP();
	
	static float valueAt(Vector3 point,float scale=255);

//-.5cos(pix)+.5
private:
	static int P[256];
	static float R[256];
	
};

int PerlinGen::P[256]={0};
float PerlinGen::R[256]={0};

float PerlinGen::valueAt(G3D::Vector3 p,float scale)
{
	p = p*(scale/255);
	int lowX = iFloor(p.x);
	int lowY = iFloor(p.y);
	int lowZ = iFloor(p.z);
	int highX= iCeil(p.x);
	int highY= iCeil(p.y);
	int highZ= iCeil(p.z);

	if(highX==lowX)
		highX=lowX+1;
	if(highY==lowY)
		highY=lowY+1;


	/*float Dll = (p - Vector3(lowX,lowY,0)).magnitude();
	float Dlh = (p - Vector3(lowX,highY,0)).magnitude();
	float Dhl = (p - Vector3(highX,lowY,0)).magnitude();
	float Dhh = (p - Vector3(highX,highY,0)).magnitude();
*/

/*	float Vll =R[(lowX+P[lowY])&0xff];
	float Vlh =R[(lowX+P[highY])&0xff];
	float Vhl =R[(highX+P[lowY])&0xff];
	float Vhh =R[(highX+P[highY])&0xff];
	

	float I = (1-cos(pi()*(p.x - lowX)))*.5;
	float Ixl = Vll*(1-I) + Vhl*(I);
	float Ixh = Vlh*(1-I) + Vhh*(I);
	I = (1-cos(pi()*(p.y - lowY)))*.5;
	float val = Ixl*(1-I) + Ixh*(I);

	if(val==0)
		val=Vhh;
//	if(val<0)
//		val=0;
	if(val>1)
		val=1;
	return val;
	*/
	float Vlll =R[(lowX+P[(lowY+ P[lowZ ])&0xff])&0xff];
	float Vllh =R[(lowX+P[(lowY+ P[highZ])&0xff])&0xff];
	float Vlhl =R[(lowX+P[(highY+P[lowZ ])&0xff])&0xff];
	float Vlhh =R[(lowX+P[(highY+P[highZ])&0xff])&0xff];
	
	float Vhll =R[(highX+P[(lowY+ P[lowZ ])&0xff])&0xff];
	float Vhlh =R[(highX+P[(lowY+ P[highZ])&0xff])&0xff];
	float Vhhl =R[(highX+P[(highY+P[lowZ ])&0xff])&0xff];
	float Vhhh =R[(highX+P[(highY+P[highZ])&0xff])&0xff];
	

	float I = (1-cos(pi()*(p.z - lowZ)))*.5;
	
	float Zll = Vlll*(1-I) + Vllh*(I);
	float Zlh = Vlhl*(1-I) + Vlhh*(I);
	float Zhl = Vhll*(1-I) + Vhlh*(I);
	float Zhh = Vhhl*(1-I) + Vhhh*(I);

	I = (1-cos(pi()*(p.y - lowY)))*.5;
	
	float Yl = Zll*(1-I) + Zlh*(I);
	float Yh = Zhl*(1-I) + Zhh*(I);

	I = (1-cos(pi()*(p.x - lowX)))*.5;
	
	float val = Yl*(1-I) + Yh*(I);

//	if(val==0)
//		val=Vhhh;
//	if(val<0)
//		val=0;
	if(val>1)
		val=1;
	return val;
}
void PerlinGen::scrambleP()
{
	for(int i=0;i<256;i++)
	{	
		P[i] = i;
		R[i] = uniformRandom(-1,1);
	}	
	for(int i=0;i<256;i++)
	{
		int temp = P[i];
		int indx = iRandom(0,255);
		P[i]=P[indx];
		P[indx]=temp;
	}

	
}

#endif