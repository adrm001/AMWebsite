///////////////////////////////////////////////////////////////////////
//
//  File				:	game.h
//  Classes				:	Cgame
//  Description			:	The header for the game application file
//
////////////////////////////////////////////////////////////////////////
#ifndef game_H
#define game_H

// The main G3D header
#include <G3DAll.h>
#include "scene.h"



class	CApp;

///////////////////////////////////////////////////////////////////////
// Class				:	Cgame
// Description			:	This class encapsulates a single window
// Comments				:	Create different applets for different portions
//							of your game. For example, main game menu, loading screen
//							and the actual game are different applets each of which 
//							having its own game loop.
class Cgame : public GApplet {
public:

					Cgame(CApp	*app);
	virtual			~Cgame();

					// The following functions are called to do specific actions
	virtual void	onInit();
	virtual void	onLogic();
	virtual void	onNetwork();
	virtual void	onSimulation(RealTime rdt, SimTime sdt, SimTime idt);
	virtual void	onGraphics(RenderDevice* rd);
	virtual void	onUserInput(UserInput* ui);
	virtual void	onCleanup();
	RealTime accum;

protected:
					// Pointer to the application so we can access the global data
	CApp			*app;

					// A texture we use for this game
	TextureRef		texture;



	SkyRef sky;
	GameTime  time;
	
	Scene	scene;
};


#endif




