///////////////////////////////////////////////////////////////////////
//
//  File				:	main.cpp
//  Classes				:
//  Description			:	The entry point for the application
//
////////////////////////////////////////////////////////////////////////
#include "application.h"
//#include "game.h"
#define _WIN32_DCOM 
//#include "MP3.h"


///////////////////////////////////////////////////////////////////////
// Function				:	main
// Description			:	The application entry point. Just spawn our application
// Return Value			:	-
// Comments				:
int	main(int argc,char *argv[]) {

	//CoInitializeEx(NULL, COINIT_MULTITHREADED);
	// This class holds the window settings for our game
	GAppSettings settings;
	//MP3 mp3("../data/soundTrack1.mp3");
	//mp3.Play();






	//sound.Play();

    settings.window.width = 800;
    settings.window.height = 600;
	settings.window.framed = true;
	settings.window.fullScreen = false;
	
	// Instantiate / run our application.
	// run() calls the main() in our application
    CApp(settings).run();
	//mp3.Stop();
	//CoUninitialize();

	return 0;
}