#ifndef MESH_H
#define MESH_H

// The main G3D header
#include <G3DAll.h>
#include "tank.h"



using namespace std;
class MTriangle;
class Mesh;
class ScalarField;

class VoxV
{
public:
	VoxV(){p=Vector3(0,0,0);state=OUTSIDE;normal=Vector3(0,1,0);}
	VoxV(const Vector3 &pp){p=pp;normal=Vector3(0,1,0);state=OUTSIDE;}
	Vector3 p;
	Vector3 normal;
	enum State {INSIDE,OUTSIDE,ON};
	enum State state;
	float dist;
};

class Voxel
{
public:
	Voxel(){}
	~Voxel(){}
	Array<MTriangle*> triangles;
	void cleanUP(){if(triangles.size()>0) triangles.deleteAll();}

};
class Ver
{
public:
	Ver(){}
	Ver(Vector3 tp)
	{
		p=tp;
	}
	~Ver(){}
	bool operator == (const Ver &v)
	{
		return this->p.fuzzyEq(v.p);
	}
	/*void addNeigh(int ng)
	{
		neighboors.insert(ng);
	}*/
	Vector3 p;
	Vector3 n;
	
	//Set<int> neighboors;//triangle index
};


class Vox
{
public:
	Vox(){}
	~Vox(){}
//          y
//          ^
//          |
//          |
//          4--(4)----5
//         /|        /|
//       (7)|      (5)|
//       / (8)     / (9)
//      7----(6)--6   |		
//      |   0-(0)-|---1---------->x	  
//    (11) /    (10) /
//      |(3)      |(1)
//      |/        |/
//      3---(2)---2
//     / 
//    /
//   /
//  z

	int CornerIndx[8][3];
	void setVox(int x,int y,int z)
	{
		CornerIndx[0][0] = x;
		CornerIndx[0][1] = y;
		CornerIndx[0][2] = z;

		CornerIndx[1][0] = x + 1;
		CornerIndx[1][1] = y;
		CornerIndx[1][2] = z;

		CornerIndx[2][0] = x + 1;
		CornerIndx[2][1] = y;
		CornerIndx[2][2] = z + 1;

		CornerIndx[3][0] = x;
		CornerIndx[3][1] = y;
		CornerIndx[3][2] = z + 1;


		CornerIndx[4][0] = x;
		CornerIndx[4][1] = y + 1;
		CornerIndx[4][2] = z;

		CornerIndx[5][0] = x + 1;
		CornerIndx[5][1] = y + 1;
		CornerIndx[5][2] = z;

		CornerIndx[6][0] = x + 1;
		CornerIndx[6][1] = y + 1;
		CornerIndx[6][2] = z + 1;

		CornerIndx[7][0] = x;
		CornerIndx[7][1] = y + 1;
		CornerIndx[7][2] = z + 1;
	}
};
class Boxel:public AABox{
public:
	Boxel():AABox(){}

	Boxel(Vector3 p,Vector3 s, float voxS,float voxS1,float voxS2,const float cloud[256][256],ScalarField *scfd);
	~Boxel(){}
	void render(RenderDevice *rd,Vector3 campos);
	void createVars();

	
private:
	
	
	Vector3 interpolate(Vector3 p1, Vector3 p2);
	
	Vector3 size;
	Vector3	position;
	float voxSize[3];
	int numx[3];
	int numy[3];
	int numz[3];
	Array<int> backindx;
	int currentLOD;
	ScalarField *imp;

	VARAreaRef varArea[3];
	VAR nVAR[3];
	VAR vVAR[3];
	Array<Vector3> versARR[3];
	Array<Vector3> normsARR[3];

	

	
};

class ScalarField:public AABox{
public:
	ScalarField():AABox(){}
	ScalarField(Vector3 p,Vector3 s, float voxS,float voxS1,float voxS2,const float cloud[256][256],Mesh *m);
	~ScalarField(){}
	void render(RenderDevice *rd,GCamera *cam);
	//void fixLink();
	void kill(Sphere &sphere);
	bool closeToSurface(Vector3 point);
	float valueAt(Vector3 point);//assumes point is inside the Boxel or inf
	Vector3 normalAt(Vector3 point);//assumes point is inside the Boxel or inf
	static Vector3 interpolateWDist(Vector3 p1,float v1,Vector3 p2, float v2);
	void initNormals();
	Array<MTriangle*> getIntTris(AABox boxie,int LOD);
	void cleanUP()
	{
		for(int i=0;i<voxels.size();i++)
			for(int x=0;x<voxels[i].size();x++)
				for(int y=0;y<voxels[i][x].size();y++)
					for(int z=0;z<voxels[i][x][y].size();z++)
					{	
						voxels[i][x][y][z].cleanUP();
					}
		
	}
	friend class MTriangle;
	friend class Boxel;
private:
	void polygonize();
	void polygonizeVox(int LOD);

	Vector3 interpolate(Vector3 p1, Vector3 p2);
	void createVars();
	
	Vector3 size;
	Vector3	position;
	bool kl;
	float voxSize[3];
	int numx[3];
	int numy[3];
	int numz[3];
	int currentLOD;
	Mesh *mesh;

	Array<Array<Array<Array<VoxV>>>> points;
	Array<Array<Array<Array<Voxel>>>> voxels;
	Array<Array<Boxel*>> boxes;
	
	Sphere ksphere;
	AABSPTree<AABox*> tree;

	Vox vox;
};
class Mesh{

public:

	Mesh(){}
	Mesh(TextureRef t,int dim);
	~Mesh(){}
	void render(RenderDevice *rd,GCamera *cam);
	void nextT();
	void kill();
	void killAt(Vector3 point);
	void moveKil(Vector3 d);
	bool intersect(Particle *part, Vector3 &result,RealTime time);
	float valueAt(Vector3 point);
	Vector3 normalAt(Vector3 point);
	bool onSurface(Vector3 point,RenderDevice *rd=0);
	bool toSurface(Vector3 Ppos,Vector3 Pos, Vector3 &result);
		void update(RealTime t){time+=t; if(time>=twoPi()){time=0;}}
	void cleanUP()
	{
		imp->cleanUP();
		delete imp;
	}
private:


	float cloud[256][256];
	GImage	icloud;
	Vector3 killpos;
	TextureRef texture;
	ScalarField *imp;
		ShaderRef shader;
		RealTime time;
	
	
};
class MTriangle
{
public:
	MTriangle(Ver on1,Ver tw,Ver thr)
	{
		one=on1;
		two=tw;
		three=thr;
		//box=b;
		//edge=e;
		//LOD=lod;
	}
	MTriangle(){}
	~MTriangle(){}
	void render(RenderDevice *rd)
	{
		//if(!edge)
		//{


			rd->setNormal (one.n);
			rd->sendVertex(one.p);
			
			rd->setNormal (two.n);
			rd->sendVertex(two.p);

			rd->setNormal (three.n);
			rd->sendVertex(three.p);
		//}
	}
	Vector3 normal_area()
	{
		Vector3 v1 = two.p - one.p;
		Vector3 v2 = three.p - one.p;
		return (v1.cross(v2));
	}
	/*int getOne(){return one;}
	int getTwo(){return two;}
	int getThree(){return three;}*/
	Vector3 getOneV(){return one.p;}
	Vector3 getTwoV(){return two.p;}
	Vector3 getThreeV(){return three.p;}
	Vector3 getOneN(){return one.n;}
	Vector3 getTwoN(){return two.n;}
	Vector3 getThreeN(){return three.n;}
	
private:
	Ver one,two,three;
//	bool edge;
//	int LOD;
//	Boxel *box;

};
#endif




