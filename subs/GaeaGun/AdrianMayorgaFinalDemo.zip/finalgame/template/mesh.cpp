#include "mesh.h"
#include "MCTable.h"
#include "perlingen.h"
#define SHADE_SUPPORT true

Mesh::Mesh(TextureRef t,int dim)
{
	
	
	srand(G3D::System::getCycleCount());
	PerlinGen::scrambleP();
	this->killpos=Vector3(0,0,0);
	icloud= GImage(256,256);
	Color3uint8 *color = icloud.pixel3();
	for(int x=0;x<256;x++)
		for(int y=0;y<256;y++)
		{
			cloud[x][y] = ((G3D::abs(PerlinGen::valueAt(Vector3(x*.1,y*.1,0)))+
							G3D::abs(PerlinGen::valueAt(Vector3(x*.2,y*.2,0))))/2);
			
			//cloud[x][y] = .5f;
			color[x*256+y]= Color3uint8(Color3(cloud[x][y],cloud[x][y],cloud[x][y]));
			
			cloud[x][y] = (((PerlinGen::valueAt(Vector3(x*.1,y*.1,0)))+
							(PerlinGen::valueAt(Vector3(x*.2,y*.2,0)))+2)/4);
			
			if(x<4||y<4||x>12*dim-1||y>12*dim-1)
				cloud[x][y]=-3;
		}
	
for(int x=0;x<256;x++)
{	
	for(int y=0;y<256;y++)
	{
		if(x>256/2)
			color[x*256+y]=color[(257-x)*256+y];
	}
}
for(int x=0;x<256;x++)
{	
	for(int y=0;y<256;y++)
	{
		if(y>256/2)
			color[x*256+y]=color[x*256+(257-y)];
	}
}
	for(int x=0;x<10;x++)
	{	
		for(int y=0;y<12*dim;y++)
		{
			cloud[x][y]=cloud[x][y]*sin(x/10.0f*halfPi())- (x<4?(-x/3.0f+3.0f):0.0f);
		}
	}
	for(int x=0;x<12*dim;x++)
	{	
		for(int y=0;y<10;y++)
		{
			cloud[x][y]=cloud[x][y]*sin(y/10.0f*halfPi())- (y<4?(-y/3.0f+3.0f):0.0f);
		}
	}
	for(int x=0;x<12*dim;x++)
	{	
		for(int y=0;y<10;y++)
		{
			cloud[x][y+12*dim-10]=cloud[x][y+12*dim-10]*cos(y/10.0f*halfPi())- (y>6?(-(y-6)/3.0f+3.0f):0.0f);
		}
	}
	for(int x=0;x<10;x++)
	{	
		for(int y=0;y<12*dim;y++)
		{
			cloud[x+12*dim-10][y]=cloud[x+12*dim-10][y]*cos(x/10.0f*halfPi())- (x>6?(-(x-6)/3.0f+3.0f):0.0f);
		}
	}
	/*for(int x=2;x<254;x++)
		for(int y=2;y<254;y++)
		{
			cloud[x][y] = (41*cloud[x][y]+ 
							26*cloud[x+1][y]+26*cloud[x][y+1]+26*cloud[x-1][y]+26*cloud[x][y-1]+
							16*cloud[x+1][y+1]+16*cloud[x-1][y+1]+16*cloud[x-1][y-1]+16*cloud[x+1][y-1]+
							7*cloud[x+2][y]+7*cloud[x-2][y]+7*cloud[x][y+2]+7*cloud[x][y-2]+
							7*cloud[x+2][y+1]+7*cloud[x-2][y-1]+7*cloud[x+1][y+2]+7*cloud[x-1][y-2]+
							7*cloud[x+2][y-1]+7*cloud[x-2][y+1]+7*cloud[x-1][y+2]+7*cloud[x+1][y-2]+
							7*cloud[x+2][y+2]+7*cloud[x-2][y+2]+7*cloud[x+2][y-2]+7*cloud[x-2][y-2])/321;

			//color[256*y+x] = Color3uint8(Color3(cloud[x][y],cloud[x][y],cloud[x][y]));
		}*/
		


	texture = Texture::fromGImage("w",icloud);

	
	imp = new ScalarField(Vector3(0,0,0),Vector3(12*dim,20,12*dim),1,2,4,cloud,this);
	shader = Shader::fromFiles("../data/bump.vert","../data/bump.frag");
	time=0;
}

void Mesh::render(G3D::RenderDevice *rd, GCamera *cam)
{
	rd->pushState();

		rd->disableLighting();
	//	rd->setTexture(3,texture);
		/*rd->setColor(Color3::white());
		rd->beginPrimitive(RenderDevice::QUADS);
		
		rd->setTexCoord(3,Vector2(0,0));
		rd->sendVertex(Vector3(0,0,-10));

		rd->setTexCoord(3,Vector2(1,0));
		rd->sendVertex(Vector3(10,0,-10));

		rd->setTexCoord(3,Vector2(1,1));
		rd->sendVertex(Vector3(10,10,-10));

		rd->setTexCoord(3,Vector2(0,1));
		rd->sendVertex(Vector3(0,10,-10));
		rd->endPrimitive();*/
		if(SHADE_SUPPORT)
		{
		shader->args.set("wsLightPos",      Vector4(cam->getCoordinateFrame().lookVector(), 0));
		shader->args.set("wsEyePos",        cam->getCoordinateFrame().translation);
        shader->args.set("texture",         texture);
        shader->args.set("normalBumpMap",   texture);
        shader->args.set("reflectivity",    0);//0.35);
	    shader->args.set("specularity",     0);//0.4);
	    shader->args.set("bumpScale",      .04f);
		shader->args.set("time",			(float)time);
	//	shader->args.set("environmentMap",  scene->game->sky->getEnvironmentMap());
		rd->setShader(shader);
		
		rd->setColor(Color3::white());
		rd->beginPrimitive(RenderDevice::QUADS);
		
		rd->setTexCoord(2,Vector2(0,0));
		rd->setTexCoord(1,Vector2(0,0));
		rd->setTexCoord(0,Vector2(0,0));
		rd->setNormal(Vector3(0,1,0));
		rd->sendVertex(Vector3(-1000,2.5,-1000));

		rd->setTexCoord(3,Vector2(0,10));
		rd->setTexCoord(2,Vector2(0,10));
		rd->setTexCoord(1,Vector2(0,10));
		rd->setTexCoord(0,Vector2(0,10));
		rd->setNormal(Vector3(0,1,0));
		rd->sendVertex(Vector3(-1000,2.5,1000));

		rd->setTexCoord(3,Vector2(10,10));
		rd->setTexCoord(2,Vector2(10,10));
		rd->setTexCoord(1,Vector2(10,10));
		rd->setTexCoord(0,Vector2(10,10));
		rd->setNormal(Vector3(0,1,0));
		rd->sendVertex(Vector3(1000,2.5,1000));

		rd->setTexCoord(3,Vector2(10,0));
		rd->setTexCoord(2,Vector2(10,0));
		rd->setTexCoord(1,Vector2(10,0));
		rd->setTexCoord(0,Vector2(10,0));
		rd->setNormal(Vector3(0,1,0));
		rd->sendVertex(Vector3(1000,2.5,-1000));
		rd->endPrimitive();
		rd->setShader(NULL);
		}

	rd->popState();
		rd->setShininess(255);
		rd->setSpecularCoefficient(0);
	imp->render(rd,cam);
	//Draw::box(*boxes[0],rd);
	//Draw::sphere(Sphere(killpos,2),rd);
	rd->setTexture(3,texture);

}
void Mesh::moveKil(Vector3 d)
{
	killpos+=d;
}
void Mesh::kill()
{
	
		imp->kill(Sphere(killpos,2));
}
void Mesh::killAt(Vector3 point)
{
	this->killpos= point;
	this->kill();
}
float Mesh::valueAt(Vector3 point)
{
	return imp->valueAt(point);
}
Vector3 Mesh::normalAt(Vector3 point)
{
	return imp->normalAt(point);
}
ScalarField::ScalarField(Vector3 p,Vector3 s, float voxS,float voxS1,float voxS2,const float cloud[256][256],Mesh *m):AABox()
{
	this->size=s;
	this->voxSize[0]=voxS;
	this->voxSize[1]=voxS1;
	this->voxSize[2]=voxS2;
	this->kl=false;
	this->position=p;
	this->mesh = m;
	this->set(position,position+size);
	int numboxes = iRound(s.x/12.0f);


	numx[0] = G3D::iRound(size.x/voxS);
	numy[0] = G3D::iRound(size.y/voxS);
	numz[0] = G3D::iRound(size.z/voxS);
	
	numx[1] = G3D::iRound(size.x/voxS1);
	numy[1] = G3D::iRound(size.y/voxS1);
	numz[1] = G3D::iRound(size.z/voxS1);
	
	numx[2] = G3D::iRound(size.x/voxS2);
	numy[2] = G3D::iRound(size.y/voxS2);
	numz[2] = G3D::iRound(size.z/voxS2);
	
	for(int LOD=0;LOD<3;LOD++)
	{
		Array<Array<Array<VoxV>>> xyArr;
		for(int x=0;x<=numx[LOD];x++)
		{
			Array<Array<VoxV>> yArr;
			for(int y=0;y<=numy[LOD];y++)
			{	
				Array<VoxV> tempArr;
				for(int z=0;z<=numz[LOD];z++)
				{
					VoxV temp = VoxV(Vector3(x*voxSize[LOD],y*voxSize[LOD],z*voxSize[LOD]));
					temp.p+=position;
					if(temp.p.y<=3+15*cloud[iRound(temp.p.x)][iRound(temp.p.z)])
						temp.state=VoxV::INSIDE;
					
					temp.dist =3+15*cloud[iRound(temp.p.x)][iRound(temp.p.z)] - temp.p.y; 
					
					tempArr.append(temp);
				}
				yArr.append(tempArr);
			}
			xyArr.append(yArr);
		}
		points.append(xyArr);
	}
	for(int LOD=0;LOD<3;LOD++)
	{
		Array<Array<Array<Voxel>>> vxyArr;
		for(int x=0;x<numx[LOD];x++)
		{
			Array<Array<Voxel>> vyArr;
			for(int y=0;y<numy[LOD];y++)
			{
				Array<Voxel> vArr;
				for(int z=0;z<numz[LOD];z++)
				{
					Voxel voxxx;
					vArr.append(voxxx);
				}
				vyArr.append(vArr);
			}
			vxyArr.append(vyArr);
		}
		voxels.append(vxyArr);
	}
	this->initNormals();

	for(int i=0;i<numboxes;i++)
	{
		Array<Boxel*> barr;
		for(int j=0;j<numboxes;j++)
		{
			barr.append( new Boxel(Vector3(i*12,0,j*12),Vector3(12,20,12),1,2,4,cloud,this));
		}
		boxes.append(barr);
	}
	for(int i=0;i<boxes.size();i++)
	{
		for(int j=0;j<boxes[i].size();j++)
		{
			tree.insert(boxes[i][j]);
		}
	}
	tree.balance();
	this->createVars();
}
Boxel::Boxel(Vector3 p,Vector3 s, float voxS,float voxS1,float voxS2,const float cloud[256][256],ScalarField *m):AABox()
{
	this->size=s;
	this->voxSize[0]=voxS;
	this->voxSize[1]=voxS1;
	this->voxSize[2]=voxS2;

	this->position=p;
	this->imp = m;
	this->set(position,position+size);


	numx[0] = G3D::iRound(size.x/voxS);
	numy[0] = G3D::iRound(size.y/voxS);
	numz[0] = G3D::iRound(size.z/voxS);
	
	numx[1] = G3D::iRound(size.x/voxS1);
	numy[1] = G3D::iRound(size.y/voxS1);
	numz[1] = G3D::iRound(size.z/voxS1);
	
	numx[2] = G3D::iRound(size.x/voxS2);
	numy[2] = G3D::iRound(size.y/voxS2);
	numz[2] = G3D::iRound(size.z/voxS2);
	this->varArea[0] = VARArea::create(sizeof(Vector3)*3*5*2*numx[0]*numy[0]*numz[0]+8,VARArea::WRITE_ONCE);
	this->varArea[1] = VARArea::create(sizeof(Vector3)*3*5*2*numx[1]*numy[1]*numz[1]+8,VARArea::WRITE_ONCE);
	this->varArea[2] = VARArea::create(sizeof(Vector3)*3*5*2*numx[2]*numy[2]*numz[2]+8,VARArea::WRITE_ONCE);
	
	
	
	
}
void ScalarField::initNormals()
{
	

	for(int x=0;x<points[0].size();x++)
	{
		for(int y=0;y<points[0][x].size();y++)
		{	
			for(int z=0;z<points[0][x][y].size();z++)
			{
				VoxV temp = points[0][x][y][z];
				Vector3 gradp = temp.p;

				float xl = valueAt(gradp+Vector3(.5f,0,0)); float xh = valueAt(gradp-Vector3(.5f,0,0));
				float yl = valueAt(gradp+Vector3(0,.5f,0)); float yh = valueAt(gradp-Vector3(0,.5f,0));
				float zl = valueAt(gradp+Vector3(0,0,.5f)); float zh = valueAt(gradp-Vector3(0,0,.5f));


				Vector3 gradn = Vector3(xl-xh,yl-yh,zl-zh);
				//if(x==points[0].size()-1||y==points[0][x].size()-1||z==points[0][x][y].size()-1)
					points[0][x][y][z].normal = -gradn.directionOrZero();
				//else
				//	points[0][x][y][z].normal = -gradn.directionOrZero();
					int sz=points[0][x][y].size();
					int sy=points[0][x].size();
					int sx=points[0].size();

				
			}
		}
	}
	for(int LOD = 1;LOD<3;LOD++)
	{
		for(int x1=0;x1<points[LOD].size();x1++)
		{
			for(int y1=0;y1<points[LOD][x1].size();y1++)
			{	
				for(int z1=0;z1<points[LOD][x1][y1].size();z1++)
				{
					Vector3 tempPos = points[LOD][x1][y1][z1].p - this->position;
					int xx = iRound(tempPos.x);
					int yy = iRound(tempPos.y);
					int zz = iRound(tempPos.z);
					points[LOD][x1][y1][z1].normal = points[0][xx][yy][zz].normal;

				}
			}
		}
	}

	polygonize();

}
void ScalarField::createVars()
{
	
	for(int i=0;i<boxes.size();i++)
	{
		for(int j=0;j<boxes[i].size();j++)
		{
			boxes[i][j]->createVars();
		}		
	}
}
void Boxel::createVars()
{
	for(int LOD =0;LOD<3;LOD++)
	{
		varArea[LOD]->reset();
		versARR[LOD].fastClear();
		normsARR[LOD].fastClear();
		int lx = iRound(position.x)/iRound(voxSize[LOD]);
		int ly = iRound(position.y)/iRound(voxSize[LOD]);
		int lz = iRound(position.z)/iRound(voxSize[LOD]);

		for(int x=lx;x<numx[LOD]+lx;x++)
		{
			for(int y=ly;y<numy[LOD]+ly;y++)
			{
				for(int z=lz;z<numz[LOD]+lz;z++)
				{
					for(int i=0;i<imp->voxels[LOD][x][y][z].triangles.size();i++)
					{	
						versARR[LOD].append(imp->voxels[LOD][x][y][z].triangles[i]->getOneV());
						versARR[LOD].append(imp->voxels[LOD][x][y][z].triangles[i]->getTwoV());
						versARR[LOD].append(imp->voxels[LOD][x][y][z].triangles[i]->getThreeV());
						
						normsARR[LOD].append(imp->voxels[LOD][x][y][z].triangles[i]->getOneN());
						normsARR[LOD].append(imp->voxels[LOD][x][y][z].triangles[i]->getTwoN());
						normsARR[LOD].append(imp->voxels[LOD][x][y][z].triangles[i]->getThreeN());
					}
				}
			}
		} 
		vVAR[LOD] = VAR(versARR[LOD],varArea[LOD]);
		nVAR[LOD] = VAR(normsARR[LOD],varArea[LOD]);
		
	}
	backindx.fastClear();
	for(int i=0;i<versARR[2].size();i++)
	{
		this->backindx.append(versARR[2].size()-1-i);
	}

}
void ScalarField::kill(Sphere &sphere)
{
	ksphere=sphere;
	Sphere ksphereP(sphere.center,sphere.radius*2.5);
	Sphere ksphereP1(sphere.center,sphere.radius*1.05);

	AABox killbox;
	ksphereP.getBounds(killbox);

	for(int LOD=0;LOD<3;LOD++)
	{
		Vector3 low = killbox.low() - this->position;
		Vector3 high = killbox.high() - this->position;

		int lx = iFloor(low.x)/iRound(voxSize[LOD]);
		int ly = iFloor(low.y)/iRound(voxSize[LOD]);
		int lz = iFloor(low.z)/iRound(voxSize[LOD]);

		int hx = iFloor(high.x)/iRound(voxSize[LOD]);
		int hy = iFloor(high.y)/iRound(voxSize[LOD]);
		int hz = iFloor(high.z)/iRound(voxSize[LOD]);
		if(hx==lx)
			hx++;
		if(hy==ly)
			hy++;
		if(hz==lz)
			hz++;
		for(int x = G3D::max<int>(lx,0);x<G3D::min<int>(voxels[LOD].size(),hx);x++)
			for(int y = G3D::max<int>(ly,0);y<G3D::min<int>(voxels[LOD][x].size(),hy);y++)
				for(int z = G3D::max<int>(lz,0);z<G3D::min<int>(voxels[LOD][x][y].size(),hz);z++)
				{
					voxels[LOD][x][y][z].triangles.deleteAll();
					if(ksphere.contains(points[LOD][x][y][z].p))
					{	points[LOD][x][y][z].state=VoxV::OUTSIDE;
//					points[LOD][x][y][z].dist = G3D::min<float>((((sphere.center - points[LOD][x][y][z].p).magnitude())-sphere.radius),points[LOD][x][y][z].dist);
					}
					points[LOD][x][y][z].dist = G3D::min<float>((((sphere.center - points[LOD][x][y][z].p).magnitude())-sphere.radius),points[LOD][x][y][z].dist);

				}
	
	
		for(int x = G3D::max<int>(lx,0);x<G3D::min<int>(voxels[LOD].size(),hx);x++)
			for(int y = G3D::max<int>(ly,0);y<G3D::min<int>(voxels[LOD][x].size(),hy);y++)
				for(int z = G3D::max<int>(lz,0);z<G3D::min<int>(voxels[LOD][x][y].size(),hz);z++)
				{
					if(LOD==0)
					{
						Vector3 gradp = points[0][x][y][z].p;
						Vector3 gradn = Vector3(mesh->valueAt(gradp+Vector3(.5f,0,0)) - mesh->valueAt(gradp-Vector3(.5f,0,0)),
											mesh->valueAt(gradp+Vector3(0,.5f,0)) - mesh->valueAt(gradp-Vector3(0,.5f,0)),
											mesh->valueAt(gradp+Vector3(0,0,.5f)) - mesh->valueAt(gradp-Vector3(0,0,.5f)));
						points[0][x][y][z].normal = -gradn.directionOrZero();
					}
					else
					{
						Vector3 tempPos = points[LOD][x][y][z].p - this->position;
						int xx = iRound(tempPos.x);
						int yy = iRound(tempPos.y);
						int zz = iRound(tempPos.z);
						points[LOD][x][y][z].normal = points[0][xx][yy][zz].normal;
					}
				}
	}
	for(int LOD=0;LOD<3;LOD++)
	{
		Vector3 low = killbox.low() - this->position;
		Vector3 high = killbox.high() - this->position;

		int lx = iFloor(low.x)/iRound(voxSize[LOD]);
		int ly = iFloor(low.y)/iRound(voxSize[LOD]);
		int lz = iFloor(low.z)/iRound(voxSize[LOD]);

		int hx = iFloor(high.x)/iRound(voxSize[LOD]);
		int hy = iFloor(high.y)/iRound(voxSize[LOD]);
		int hz = iFloor(high.z)/iRound(voxSize[LOD]);
		if(hx==lx)
			hx++;
		if(hy==ly)
			hy++;
		if(hz==lz)
			hz++;	
		for(int x = G3D::max<int>(lx,0);x<G3D::min<int>(voxels[LOD].size(),hx);x++)
			for(int y = G3D::max<int>(ly,0);y<G3D::min<int>(voxels[LOD][x].size(),hy);y++)
				for(int z = G3D::max<int>(lz,0);z<G3D::min<int>(voxels[LOD][x][y].size(),hz);z++)
				{
					vox.setVox(x,y,z);
					polygonizeVox(LOD);
				}
	}
	kl=true;
//	initNormals();
	this->createVars();
	kl=false;
}
void ScalarField::render(G3D::RenderDevice *rd,GCamera *cam)
{
	
	Array<AABox*> arr;
	tree.getIntersectingMembers(cam->frustum(rd->getViewport()),arr);
	Vector3 campos= cam->getCoordinateFrame().translation;
	for(int i=0;i<arr.size();i++)
	{
		Boxel *temp = (Boxel*)arr[i];
		temp->render(rd,campos);
	}
	/*for(int i=0;i<boxes.size();i++)
	{
		for(int j=0;j<boxes[i].size();j++)
		{
			boxes[i][j]->render(rd);;
		}		
	}*/
}
void Boxel::render(G3D::RenderDevice *rd,Vector3 campos)
{
	//glPointSize(3);
	float dist = (campos-(this->position+this->size)/2.0f).magnitude();
	
	rd->setColor(Color3::orange());

	int lod;
	if(this->contains(campos))
		lod=0;
	else
	{
			lod=2;
		if(dist<40)
			lod=1; 
		if(dist<15)
			lod=0;
	}
	
	/*switch(lod)
	{
	case 0: rd->setColor(Color3::brown());
			break;
	case 1: rd->setColor(Color3::blue());
			break;
	case 2: rd->setColor(Color3::red());
			break;
	}*/
	lod=0;
	rd->beginIndexedPrimitives();
		rd->setNormalArray(nVAR[lod]);
		rd->setVertexArray(vVAR[lod]);
		rd->sendSequentialIndices(RenderDevice::TRIANGLES,versARR[lod].size());
	rd->endIndexedPrimitives();
	

	
}
void ScalarField::polygonize()
{
	for(int LOD=0;LOD<3;LOD++)
	{

		for(int x=0;x<numx[LOD];x++)
			for(int y=0;y<numy[LOD];y++)
				for(int z=0;z<numz[LOD];z++)
				{
					vox.setVox(x,y,z);
					polygonizeVox(LOD);
				}
	}

}

void ScalarField::polygonizeVox(int LOD)
{
	
	bool val[8]={false,false,false,false,false,false,false,false};
	for(int i=0;i<8;i++)
	{
		if(points[LOD][vox.CornerIndx[i][0]]
					[vox.CornerIndx[i][1]]
					[vox.CornerIndx[i][2]].state == VoxV::INSIDE)
					val[i]=true;
	}
	int cubeindex = 0;
	if (val[0]) cubeindex |= 1;
	if (val[1]) cubeindex |= 2;
	if (val[2]) cubeindex |= 4;
	if (val[3]) cubeindex |= 8;
	if (val[4]) cubeindex |= 16;
	if (val[5]) cubeindex |= 32;
	if (val[6]) cubeindex |= 64;
	if (val[7]) cubeindex |= 128;
	
	   // Cube is entirely in/out of the surface 
	if (MCTable::edgeTable[cubeindex] == 0)
      return;

	Vector3 vertlist[12];
	Vector3 norlist[12];

   // Find the vertices where the surface intersects the cube 
   
   if (MCTable::edgeTable[cubeindex] & 1)
   {
      vertlist[0] = interpolateWDist( points[LOD][vox.CornerIndx[0][0]]
										[vox.CornerIndx[0][1]]
										[vox.CornerIndx[0][2]].p,
								 points[LOD]	[vox.CornerIndx[0][0]]
										[vox.CornerIndx[0][1]]
										[vox.CornerIndx[0][2]].dist,
								 points[LOD]	[vox.CornerIndx[1][0]]
										[vox.CornerIndx[1][1]]
										[vox.CornerIndx[1][2]].p,
								 points [LOD][vox.CornerIndx[1][0]]
										[vox.CornerIndx[1][1]]
										[vox.CornerIndx[1][2]].dist);	
   }							
   if (MCTable::edgeTable[cubeindex] & 2)
   {
      vertlist[1] =interpolateWDist( points[LOD]	[vox.CornerIndx[1][0]]
										[vox.CornerIndx[1][1]]
										[vox.CornerIndx[1][2]].p,
								 points[LOD]	[vox.CornerIndx[1][0]]
										[vox.CornerIndx[1][1]]
										[vox.CornerIndx[1][2]].dist,
								 points[LOD]	[vox.CornerIndx[2][0]]
										[vox.CornerIndx[2][1]]
										[vox.CornerIndx[2][2]].p,
								 points[LOD]	[vox.CornerIndx[2][0]]
										[vox.CornerIndx[2][1]]
										[vox.CornerIndx[2][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 4)
   {
      vertlist[2] =interpolateWDist( points[LOD]	[vox.CornerIndx[2][0]]
										[vox.CornerIndx[2][1]]
										[vox.CornerIndx[2][2]].p,
								 points[LOD]	[vox.CornerIndx[2][0]]
										[vox.CornerIndx[2][1]]
										[vox.CornerIndx[2][2]].dist,
								 points[LOD]	[vox.CornerIndx[3][0]]
										[vox.CornerIndx[3][1]]
										[vox.CornerIndx[3][2]].p,
								 points[LOD]	[vox.CornerIndx[3][0]]
										[vox.CornerIndx[3][1]]
										[vox.CornerIndx[3][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 8)
   {
      vertlist[3] =interpolateWDist( points[LOD]	[vox.CornerIndx[3][0]]
										[vox.CornerIndx[3][1]]
										[vox.CornerIndx[3][2]].p,
								 points[LOD]	[vox.CornerIndx[3][0]]
										[vox.CornerIndx[3][1]]
										[vox.CornerIndx[3][2]].dist,
								 points[LOD]	[vox.CornerIndx[0][0]]
										[vox.CornerIndx[0][1]]
										[vox.CornerIndx[0][2]].p,
								 points[LOD]	[vox.CornerIndx[0][0]]
										[vox.CornerIndx[0][1]]
										[vox.CornerIndx[0][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 16)
   {
      vertlist[4] =interpolateWDist( points[LOD]	[vox.CornerIndx[4][0]]
										[vox.CornerIndx[4][1]]
										[vox.CornerIndx[4][2]].p,
								 points[LOD]	[vox.CornerIndx[4][0]]
										[vox.CornerIndx[4][1]]
										[vox.CornerIndx[4][2]].dist,
								 points[LOD]	[vox.CornerIndx[5][0]]
										[vox.CornerIndx[5][1]]
										[vox.CornerIndx[5][2]].p,
								 points[LOD]	[vox.CornerIndx[5][0]]
										[vox.CornerIndx[5][1]]
										[vox.CornerIndx[5][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 32)
   {
      vertlist[5] =interpolateWDist( points[LOD]	[vox.CornerIndx[5][0]]
										[vox.CornerIndx[5][1]]
										[vox.CornerIndx[5][2]].p,
								 points	[LOD][vox.CornerIndx[5][0]]
										[vox.CornerIndx[5][1]]
										[vox.CornerIndx[5][2]].dist,
								 points[LOD]	[vox.CornerIndx[6][0]]
										[vox.CornerIndx[6][1]]
										[vox.CornerIndx[6][2]].p,
								 points[LOD]	[vox.CornerIndx[6][0]]
										[vox.CornerIndx[6][1]]
										[vox.CornerIndx[6][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 64)
   {
      vertlist[6] =interpolateWDist( points[LOD]	[vox.CornerIndx[6][0]]
										[vox.CornerIndx[6][1]]
										[vox.CornerIndx[6][2]].p,
								 points[LOD]	[vox.CornerIndx[6][0]]
										[vox.CornerIndx[6][1]]
										[vox.CornerIndx[6][2]].dist,
								 points[LOD]	[vox.CornerIndx[7][0]]
										[vox.CornerIndx[7][1]]
										[vox.CornerIndx[7][2]].p,
								 points[LOD]	[vox.CornerIndx[7][0]]
										[vox.CornerIndx[7][1]]
										[vox.CornerIndx[7][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 128)
   {
      vertlist[7] =interpolateWDist( points[LOD]	[vox.CornerIndx[7][0]]
										[vox.CornerIndx[7][1]]
										[vox.CornerIndx[7][2]].p,
		   						 points[LOD]	[vox.CornerIndx[7][0]]
										[vox.CornerIndx[7][1]]
										[vox.CornerIndx[7][2]].dist,
								 points[LOD]	[vox.CornerIndx[4][0]]
										[vox.CornerIndx[4][1]]
										[vox.CornerIndx[4][2]].p,
								 points[LOD]	[vox.CornerIndx[4][0]]
										[vox.CornerIndx[4][1]]
										[vox.CornerIndx[4][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 256)
   {
      vertlist[8] =interpolateWDist( points[LOD]	[vox.CornerIndx[0][0]]
										[vox.CornerIndx[0][1]]
										[vox.CornerIndx[0][2]].p,
								 points[LOD]	[vox.CornerIndx[0][0]]
										[vox.CornerIndx[0][1]]
										[vox.CornerIndx[0][2]].dist,
								 points[LOD]	[vox.CornerIndx[4][0]]
										[vox.CornerIndx[4][1]]
										[vox.CornerIndx[4][2]].p,
								 points[LOD]	[vox.CornerIndx[4][0]]
										[vox.CornerIndx[4][1]]
										[vox.CornerIndx[4][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 512)
   {
      vertlist[9] =interpolateWDist( points[LOD]	[vox.CornerIndx[1][0]]
										[vox.CornerIndx[1][1]]
										[vox.CornerIndx[1][2]].p,
								 points[LOD]	[vox.CornerIndx[1][0]]
										[vox.CornerIndx[1][1]]
										[vox.CornerIndx[1][2]].dist,
								 points[LOD][vox.CornerIndx[5][0]]
										[vox.CornerIndx[5][1]]
										[vox.CornerIndx[5][2]].p,
								 points[LOD]	[vox.CornerIndx[5][0]]
										[vox.CornerIndx[5][1]]
										[vox.CornerIndx[5][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 1024)
   {
      vertlist[10] =interpolateWDist( points[LOD]	[vox.CornerIndx[2][0]]
										[vox.CornerIndx[2][1]]
										[vox.CornerIndx[2][2]].p,
								 points[LOD]	[vox.CornerIndx[2][0]]
										[vox.CornerIndx[2][1]]
										[vox.CornerIndx[2][2]].dist,
								 points[LOD]	[vox.CornerIndx[6][0]]
										[vox.CornerIndx[6][1]]
										[vox.CornerIndx[6][2]].p,
								 points[LOD]	[vox.CornerIndx[6][0]]
										[vox.CornerIndx[6][1]]
										[vox.CornerIndx[6][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 2048)
   {
      vertlist[11] =interpolateWDist( points[LOD]	[vox.CornerIndx[3][0]]
										[vox.CornerIndx[3][1]]
										[vox.CornerIndx[3][2]].p,
								points[LOD]	[vox.CornerIndx[3][0]]
										[vox.CornerIndx[3][1]]
										[vox.CornerIndx[3][2]].dist,
								 points[LOD]	[vox.CornerIndx[7][0]]
										[vox.CornerIndx[7][1]]
										[vox.CornerIndx[7][2]].p,
								 points[LOD]	[vox.CornerIndx[7][0]]
										[vox.CornerIndx[7][1]]
										[vox.CornerIndx[7][2]].dist);	
   }
   // Find the normals of the vertices where the surface intersects the cube 
   
   if (MCTable::edgeTable[cubeindex] & 1)
   {
      norlist[0] = interpolateWDist( points[LOD][vox.CornerIndx[0][0]]
										[vox.CornerIndx[0][1]]
										[vox.CornerIndx[0][2]].normal,
								 points[LOD]	[vox.CornerIndx[0][0]]
										[vox.CornerIndx[0][1]]
										[vox.CornerIndx[0][2]].dist,
								 points[LOD]	[vox.CornerIndx[1][0]]
										[vox.CornerIndx[1][1]]
										[vox.CornerIndx[1][2]].normal,
								 points [LOD][vox.CornerIndx[1][0]]
										[vox.CornerIndx[1][1]]
										[vox.CornerIndx[1][2]].dist);	
   }							
   if (MCTable::edgeTable[cubeindex] & 2)
   {
      norlist[1] =interpolateWDist( points[LOD]	[vox.CornerIndx[1][0]]
										[vox.CornerIndx[1][1]]
										[vox.CornerIndx[1][2]].normal,
								 points[LOD]	[vox.CornerIndx[1][0]]
										[vox.CornerIndx[1][1]]
										[vox.CornerIndx[1][2]].dist,
								 points[LOD]	[vox.CornerIndx[2][0]]
										[vox.CornerIndx[2][1]]
										[vox.CornerIndx[2][2]].normal,
								 points[LOD]	[vox.CornerIndx[2][0]]
										[vox.CornerIndx[2][1]]
										[vox.CornerIndx[2][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 4)
   {
      norlist[2] =interpolateWDist( points[LOD]	[vox.CornerIndx[2][0]]
										[vox.CornerIndx[2][1]]
										[vox.CornerIndx[2][2]].normal,
								 points[LOD]	[vox.CornerIndx[2][0]]
										[vox.CornerIndx[2][1]]
										[vox.CornerIndx[2][2]].dist,
								 points[LOD]	[vox.CornerIndx[3][0]]
										[vox.CornerIndx[3][1]]
										[vox.CornerIndx[3][2]].normal,
								 points[LOD]	[vox.CornerIndx[3][0]]
										[vox.CornerIndx[3][1]]
										[vox.CornerIndx[3][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 8)
   {
      norlist[3] =interpolateWDist( points[LOD]	[vox.CornerIndx[3][0]]
										[vox.CornerIndx[3][1]]
										[vox.CornerIndx[3][2]].normal,
								 points[LOD]	[vox.CornerIndx[3][0]]
										[vox.CornerIndx[3][1]]
										[vox.CornerIndx[3][2]].dist,
								 points[LOD]	[vox.CornerIndx[0][0]]
										[vox.CornerIndx[0][1]]
										[vox.CornerIndx[0][2]].normal,
								 points[LOD]	[vox.CornerIndx[0][0]]
										[vox.CornerIndx[0][1]]
										[vox.CornerIndx[0][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 16)
   {
      norlist[4] =interpolateWDist( points[LOD]	[vox.CornerIndx[4][0]]
										[vox.CornerIndx[4][1]]
										[vox.CornerIndx[4][2]].normal,
								 points[LOD]	[vox.CornerIndx[4][0]]
										[vox.CornerIndx[4][1]]
										[vox.CornerIndx[4][2]].dist,
								 points[LOD]	[vox.CornerIndx[5][0]]
										[vox.CornerIndx[5][1]]
										[vox.CornerIndx[5][2]].normal,
								 points[LOD]	[vox.CornerIndx[5][0]]
										[vox.CornerIndx[5][1]]
										[vox.CornerIndx[5][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 32)
   {
      norlist[5] =interpolateWDist( points[LOD]	[vox.CornerIndx[5][0]]
										[vox.CornerIndx[5][1]]
										[vox.CornerIndx[5][2]].normal,
								 points	[LOD][vox.CornerIndx[5][0]]
										[vox.CornerIndx[5][1]]
										[vox.CornerIndx[5][2]].dist,
								 points[LOD]	[vox.CornerIndx[6][0]]
										[vox.CornerIndx[6][1]]
										[vox.CornerIndx[6][2]].normal,
								 points[LOD]	[vox.CornerIndx[6][0]]
										[vox.CornerIndx[6][1]]
										[vox.CornerIndx[6][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 64)
   {
      norlist[6] =interpolateWDist( points[LOD]	[vox.CornerIndx[6][0]]
										[vox.CornerIndx[6][1]]
										[vox.CornerIndx[6][2]].normal,
								 points[LOD]	[vox.CornerIndx[6][0]]
										[vox.CornerIndx[6][1]]
										[vox.CornerIndx[6][2]].dist,
								 points[LOD]	[vox.CornerIndx[7][0]]
										[vox.CornerIndx[7][1]]
										[vox.CornerIndx[7][2]].normal,
								 points[LOD]	[vox.CornerIndx[7][0]]
										[vox.CornerIndx[7][1]]
										[vox.CornerIndx[7][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 128)
   {
      norlist[7] =interpolateWDist( points[LOD]	[vox.CornerIndx[7][0]]
										[vox.CornerIndx[7][1]]
										[vox.CornerIndx[7][2]].normal,
		   						 points[LOD]	[vox.CornerIndx[7][0]]
										[vox.CornerIndx[7][1]]
										[vox.CornerIndx[7][2]].dist,
								 points[LOD]	[vox.CornerIndx[4][0]]
										[vox.CornerIndx[4][1]]
										[vox.CornerIndx[4][2]].normal,
								 points[LOD]	[vox.CornerIndx[4][0]]
										[vox.CornerIndx[4][1]]
										[vox.CornerIndx[4][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 256)
   {
      norlist[8] =interpolateWDist( points[LOD]	[vox.CornerIndx[0][0]]
										[vox.CornerIndx[0][1]]
										[vox.CornerIndx[0][2]].normal,
								 points[LOD]	[vox.CornerIndx[0][0]]
										[vox.CornerIndx[0][1]]
										[vox.CornerIndx[0][2]].dist,
								 points[LOD]	[vox.CornerIndx[4][0]]
										[vox.CornerIndx[4][1]]
										[vox.CornerIndx[4][2]].normal,
								 points[LOD]	[vox.CornerIndx[4][0]]
										[vox.CornerIndx[4][1]]
										[vox.CornerIndx[4][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 512)
   {
      norlist[9] =interpolateWDist( points[LOD]	[vox.CornerIndx[1][0]]
										[vox.CornerIndx[1][1]]
										[vox.CornerIndx[1][2]].normal,
								 points[LOD]	[vox.CornerIndx[1][0]]
										[vox.CornerIndx[1][1]]
										[vox.CornerIndx[1][2]].dist,
								 points[LOD][vox.CornerIndx[5][0]]
										[vox.CornerIndx[5][1]]
										[vox.CornerIndx[5][2]].normal,
								 points[LOD]	[vox.CornerIndx[5][0]]
										[vox.CornerIndx[5][1]]
										[vox.CornerIndx[5][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 1024)
   {
      norlist[10] =interpolateWDist( points[LOD]	[vox.CornerIndx[2][0]]
										[vox.CornerIndx[2][1]]
										[vox.CornerIndx[2][2]].normal,
								 points[LOD]	[vox.CornerIndx[2][0]]
										[vox.CornerIndx[2][1]]
										[vox.CornerIndx[2][2]].dist,
								 points[LOD]	[vox.CornerIndx[6][0]]
										[vox.CornerIndx[6][1]]
										[vox.CornerIndx[6][2]].normal,
								 points[LOD]	[vox.CornerIndx[6][0]]
										[vox.CornerIndx[6][1]]
										[vox.CornerIndx[6][2]].dist);	
   }
   if (MCTable::edgeTable[cubeindex] & 2048)
   {
      norlist[11] =interpolateWDist( points[LOD]	[vox.CornerIndx[3][0]]
										[vox.CornerIndx[3][1]]
										[vox.CornerIndx[3][2]].normal,
								points[LOD]	[vox.CornerIndx[3][0]]
										[vox.CornerIndx[3][1]]
										[vox.CornerIndx[3][2]].dist,
								 points[LOD]	[vox.CornerIndx[7][0]]
										[vox.CornerIndx[7][1]]
										[vox.CornerIndx[7][2]].normal,
								 points[LOD]	[vox.CornerIndx[7][0]]
										[vox.CornerIndx[7][1]]
										[vox.CornerIndx[7][2]].dist);	
   }

   // Create the triangle 
   voxels[LOD][vox.CornerIndx[0][0]][vox.CornerIndx[0][1]][vox.CornerIndx[0][2]].triangles.deleteAll();
	for (int i=0;MCTable::triTable[cubeindex][i]!=-1;i+=3) 
	{
		Ver one(vertlist[MCTable::triTable[cubeindex][i  ]]);
		Ver two(vertlist[MCTable::triTable[cubeindex][i+1]]);
		Ver three(vertlist[MCTable::triTable[cubeindex][i+2]]);
		one.n   = (norlist[MCTable::triTable[cubeindex][i  ]]);
	
		two.n   = (norlist[MCTable::triTable[cubeindex][i+1]]);
	
		three.n = (norlist[MCTable::triTable[cubeindex][i+2]]);
		
		
		MTriangle *tri = new MTriangle(one,two,three);
		//triangles[LOD].insert(tri);
		voxels[LOD][vox.CornerIndx[0][0]][vox.CornerIndx[0][1]][vox.CornerIndx[0][2]].triangles.append(tri);
	}
}
Vector3 ScalarField::interpolate(G3D::Vector3 p1, G3D::Vector3 p2)
{
	
	return (p1+p2)/2;
}
Vector3 ScalarField::interpolateWDist(Vector3 p1,float v1,Vector3 p2, float v2)
{
	
		if (G3D::abs(v1) < 0.00001)
			return(p1);
		if (G3D::abs(v2) < 0.00001)
			return(p2);
		if (G3D::abs(v1-v2) < 0.00001)
			return(p1);

		float mu = (-v1) / (v2 - v1);
		Vector3 p;
		p.x = p1.x + mu * (p2.x - p1.x);
		p.y = p1.y + mu * (p2.y - p1.y);
		p.z = p1.z + mu * (p2.z - p1.z);
		
		return p;
	
}
bool ScalarField::closeToSurface(Vector3 point)
{
	point-=this->position;

	int x = iFloor(point.x);
	int y = iFloor(point.y);
	int z = iFloor(point.z);
	if(	x>=this->numx[0]||
		y>=this->numy[0]||
		z>=this->numz[0])
		return false;


	/*if(points[0][x  ][y  ][z  ].state==VoxV::INSIDE&&
	points[0][x  ][y  ][z+1].state==VoxV::INSIDE&&
	points[0][x  ][y+1][z  ].state==VoxV::INSIDE&&
	points[0][x  ][y+1][z+1].state==VoxV::INSIDE&&
	points[0][x+1][y  ][z  ].state==VoxV::INSIDE&&
	points[0][x+1][y  ][z+1].state==VoxV::INSIDE&&
	points[0][x+1][y+1][z  ].state==VoxV::INSIDE&&
	points[0][x+1][y+1][z+1].state==VoxV::INSIDE)
		return false;*/

	return (points[0][x  ][y  ][z  ].state==VoxV::INSIDE||
			points[0][x  ][y  ][z+1].state==VoxV::INSIDE||
			points[0][x  ][y+1][z  ].state==VoxV::INSIDE||
			points[0][x  ][y+1][z+1].state==VoxV::INSIDE||
			points[0][x+1][y  ][z  ].state==VoxV::INSIDE||
			points[0][x+1][y  ][z+1].state==VoxV::INSIDE||
			points[0][x+1][y+1][z  ].state==VoxV::INSIDE||
			points[0][x+1][y+1][z+1].state==VoxV::INSIDE);


}
Vector3 ScalarField::normalAt(G3D::Vector3 point)
{
	if(!this->contains(point))
		return Vector3::inf();
	point-=this->position;

	int x = iFloor(point.x);
	int y = iFloor(point.y);
	int z = iFloor(point.z);
	if(	x>=this->numx[0]||
		y>=this->numy[0]||
		z>=this->numz[0])
		return Vector3::inf();
	
	float dx = point.x-x;
	float dy = point.y-y;
	float dz = point.z-z;
	
	Vector3 ntemp = points[0][x][y][z].normal; 
this->vox.setVox(x,y,z);

	Vector3 Zll = lerp(	points[0][vox.CornerIndx[0][0]]
								 [vox.CornerIndx[0][1]]
								 [vox.CornerIndx[0][2]].normal,
						points[0][vox.CornerIndx[3][0]]
								 [vox.CornerIndx[3][1]]
								 [vox.CornerIndx[3][2]].normal,dz);
	if(dz==0)
		Zll =  points[0][vox.CornerIndx[0][0]]
						[vox.CornerIndx[0][1]]
						[vox.CornerIndx[0][2]].normal;
	
	Vector3 Zhl = lerp(	points[0][vox.CornerIndx[1][0]]
								 [vox.CornerIndx[1][1]]
								 [vox.CornerIndx[1][2]].normal,
						points[0][vox.CornerIndx[2][0]]
								 [vox.CornerIndx[2][1]]
								 [vox.CornerIndx[2][2]].normal,dz);
	if(dz==0)
		Zhl =  points[0][vox.CornerIndx[1][0]]
						[vox.CornerIndx[1][1]]
						[vox.CornerIndx[1][2]].normal;

	Vector3 Zlh = lerp(	points[0][vox.CornerIndx[4][0]]
								 [vox.CornerIndx[4][1]]
								 [vox.CornerIndx[4][2]].normal,
						points[0][vox.CornerIndx[7][0]]
								 [vox.CornerIndx[7][1]]
								 [vox.CornerIndx[7][2]].normal,dz);
	if(dz==0)
		Zlh =  points[0][vox.CornerIndx[4][0]]
						[vox.CornerIndx[4][1]]
						[vox.CornerIndx[4][2]].normal;
 	Vector3 Zhh = lerp(	points[0][vox.CornerIndx[5][0]]
								 [vox.CornerIndx[5][1]]
								 [vox.CornerIndx[5][2]].normal,
						points[0][vox.CornerIndx[6][0]]
								 [vox.CornerIndx[6][1]]
								 [vox.CornerIndx[6][2]].normal,dz);
	if(dz==0)
		Zhh =  points[0][vox.CornerIndx[5][0]]
						[vox.CornerIndx[5][1]]
						[vox.CornerIndx[5][2]].normal;
	Vector3 Yl = lerp(Zll,Zlh,dy);
	if(dy==0)
		Yl =  Zll;
	Vector3 Yh = lerp(Zhl,Zhh,dy);
	if(dy==0)
		Yh =  Zhl;
	Vector3 val = lerp(Yl,Yh,dx);
	if(dx==0)
		val = Yl;
	Vector3 vall = val.directionOrZero();

	return vall;//OrZero();


}
float ScalarField::valueAt(Vector3 point)
{
	if(!this->contains(point))
		return G3D::inf();
	
	point-=this->position;

	int x = iFloor(point.x);
	int y = iFloor(point.y);
	int z = iFloor(point.z);
	if(	x<0||
		y<0||
		z<0||
		x>=this->numx[0]||
		y>=this->numy[0]||
		z>=this->numz[0])
		return 0;//G3D::inf();

	float dx = point.x-x;
	float dy = point.y-y;
	float dz = point.z-z;

	this->vox.setVox(x,y,z);

	float Zll = lerp(	points[0][vox.CornerIndx[0][0]]
								 [vox.CornerIndx[0][1]]
								 [vox.CornerIndx[0][2]].dist,
						points[0][vox.CornerIndx[3][0]]
								 [vox.CornerIndx[3][1]]
								 [vox.CornerIndx[3][2]].dist,dz);
	float Zhl = lerp(	points[0][vox.CornerIndx[1][0]]
								 [vox.CornerIndx[1][1]]
								 [vox.CornerIndx[1][2]].dist,
						points[0][vox.CornerIndx[2][0]]
								 [vox.CornerIndx[2][1]]
							     [vox.CornerIndx[2][2]].dist,dz);
	float Zlh = lerp(	points[0][vox.CornerIndx[4][0]]
								 [vox.CornerIndx[4][1]]
								 [vox.CornerIndx[4][2]].dist,
						points[0][vox.CornerIndx[7][0]]
								 [vox.CornerIndx[7][1]]
								 [vox.CornerIndx[7][2]].dist,dz);
 	float Zhh = lerp(	points[0][vox.CornerIndx[5][0]]
								 [vox.CornerIndx[5][1]]
								 [vox.CornerIndx[5][2]].dist,
						points[0][vox.CornerIndx[6][0]]
								 [vox.CornerIndx[6][1]]
								 [vox.CornerIndx[6][2]].dist,dz);
	float Yl = lerp(Zll,Zlh,dy);
	float Yh = lerp(Zhl,Zhh,dy);
	float val = lerp(Yl,Yh,dx);
	//if(val==0&&point.y!=10.5f)
	//	cout<<"huh";
	return val;
}
Array<MTriangle*> ScalarField::getIntTris(AABox boxie,int LOD)
{
	Vector3 low = boxie.low() - this->position;
	Vector3 high = boxie.high() - this->position;

	int lx = iFloor(low.x)/iRound(voxSize[LOD]);
	int ly = iFloor(low.y)/iRound(voxSize[LOD]);
	int lz = iFloor(low.z)/iRound(voxSize[LOD]);

	int hx = iFloor(high.x)/iRound(voxSize[LOD]);
	int hy = iFloor(high.y)/iRound(voxSize[LOD]);
	int hz = iFloor(high.z)/iRound(voxSize[LOD]);
	if(hx==lx)
		hx++;
	if(hy==ly)
		hy++;
	if(hz==lz)
		hz++;

	Array<MTriangle*> tris;
	for(int x = G3D::max<int>(lx,0);x<G3D::min<int>(voxels[LOD].size(),hx);x++)
		for(int y = G3D::max<int>(ly,0);y<G3D::min<int>(voxels[LOD][x].size(),hy);y++)
			for(int z = G3D::max<int>(lz,0);z<G3D::min<int>(voxels[LOD][x][y].size(),hz);z++)
			{
				tris.append(voxels[LOD][x][y][z].triangles);
			}
	return tris;
}
bool Mesh::intersect(Particle *part, G3D::Vector3 &result,RealTime time)
{
	//if(!(part->getGo()))
	//	return false;
	if(part->getPos().y<0)
	{
		result=part->getPos();
		return true;
	}
	Vector3 Ppos = part->getPPos();
	Vector3 Pos  = part->getPos();
	Vector3 dir =  (Ppos-Pos).directionOrZero();
	Vector3 Vel  = part->getVel();

	
	float ppv,pv;
	pv = this->valueAt(Pos);
	ppv = this->valueAt(Ppos);
	if((!(isFinite(pv)))||(!(isFinite(ppv))))
		return false;
	if(pv<0||ppv>0)
		return false;
	else
	{
		//Boxel::interpolateWDist(Ppos,ppv,Pos,pv);
		float rv;
		int Maxiters=5;
		do{
			result = (Ppos + Pos)/2;
			rv = this->valueAt(result);
			if(rv<0)
			{
				Ppos = result;

			}
			else
			{
				Pos = result;
			}
			Maxiters--;
		}while(Maxiters>=0&&G3D::abs(rv)>.01f);
		result = result ;//+dir*.5f;

	
		return true;
	}


	


}
bool Mesh::onSurface(Vector3 point,RenderDevice *rd)
{
	
/*
	
	Array<MTriangle*> tris;
	for(int i=0;i<boxes.size();i++)
	{
		for(int j=0;j<boxes[i].size();j++)
		{
			if(boxes[i][j]->contains(point))
				tris.append(boxes[i][j]->getIntTris(AABox(point,point),0));
		}
	}
	for(int i=0;i<tris.size();i++)
	{
		Plane pln(tris[i]->getOneV(),tris[i]->getTwoV(),tris[i]->getThreeV());
		Vector3 testSite = pln.closestPoint(point);
		bool test = CollisionDetection::isPointInsideTriangle(tris[i]->getOneV(),tris[i]->getTwoV(),tris[i]->getThreeV(),pln.normal(),testSite);
		if(test&&testSite.fuzzyEq(point))
		{
			if(rd!=0)
			{
				rd->beginPrimitive(RenderDevice::TRIANGLES);
				rd->setColor(Color3::blue());
				tris[i]->render(rd);
				rd->endPrimitive();
			}
			return true;
		}
	}*/
	return false;
}
bool Mesh::toSurface(Vector3 Ppos, G3D::Vector3 Pos, G3D::Vector3 &result)
{
	Vector3 dir =  (Ppos-Pos).directionOrZero();
	float ppv,pv;
	pv = this->valueAt(Pos);
	ppv = this->valueAt(Ppos);
	if((!(isFinite(pv)))||(!(isFinite(ppv))))
		return false;
	if(pv<0||ppv>0)
		return false;
	else
	{
		//Boxel::interpolateWDist(Ppos,ppv,Pos,pv);
		float rv;
		int Maxiters=5;
		do{
			result = (Ppos + Pos)/2;
			rv = this->valueAt(result);
			if(rv<0)
			{
				Ppos = result;

			}
			else
			{
				Pos = result;
			}
			Maxiters--;
		}while(Maxiters>=0&&G3D::abs(rv)>.01f);
		result = result ;//+dir*.5f;

		return true;
	}

}