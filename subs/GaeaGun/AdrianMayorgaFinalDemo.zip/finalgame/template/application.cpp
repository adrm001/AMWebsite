///////////////////////////////////////////////////////////////////////
//
//  File				:	application.cpp
//  Classes				:	CApp
//  Description			:	The implementation of the CApp class
//
////////////////////////////////////////////////////////////////////////
#include "application.h"
#include "fmodsound.h"


///////////////////////////////////////////////////////////////////////
// Class				:	CApp
// Method				:	CApp
// Description			:	Ctor
// Return Value			:	-
// Comments				:
CApp::CApp(const GAppSettings& settings) : GApp(settings) {

	// Set the application window caption
	renderDevice->setCaption("CS 378 - Game technology game");
}

///////////////////////////////////////////////////////////////////////
// Class				:	CApp
// Method				:	~CApp
// Description			:	Dtor
// Return Value			:	-
// Comments				:
CApp::~CApp() {
	// Nothing to do here
}

///////////////////////////////////////////////////////////////////////
// Class				:	CApp
// Method				:	main
// Description			:	The main function. Implement your game loop here
// Return Value			:	-
// Comments				:
ArticulatedModelRef Tank::model_base=ArticulatedModel::fromFile("../data/ifs/standbase.3DS");
ArticulatedModelRef Tank::model_cabin=ArticulatedModel::fromFile("../data/ifs/standcabin.3DS");
ArticulatedModelRef Tank::model_turret=ArticulatedModel::fromFile("../data/ifs/standturret.3DS");
ArticulatedModelRef Particle::model_misil=ArticulatedModel::fromFile("../data/ifs/misil.3DS");

Array<PosedModelRef> Tank::base_mod;
Array<PosedModelRef> Tank::cabin_mod;
Array<PosedModelRef> Tank::turret_mod;
Array<PosedModelRef> Particle::misil_mod;


void	CApp::main() {

GameSound music("../data/soundTrack1.mp3",true);



	music.Play();
	Tank::model_base->pose(Tank::base_mod);
	Tank::model_cabin->pose(Tank::cabin_mod);
	Tank::model_turret->pose(Tank::turret_mod);
	Particle::model_misil->pose(Particle::misil_mod);
	// We're debugging
	setDebugMode(false);
curScreen = TITLE;
	// Allow the user the control the camera
	debugController.setActive(false);
	debugController.setMoveRate(6);

	// Do not show the rendering stats
	// You may want to turn this on to find out various info in your game
	debugShowRenderingStats =false;
	while(!endProgram){
		switch(curScreen)
		{
			case TITLE:		CTemplate(this).run();
							break;
			case CONTROLS:	CControls(this).run();
							break;
			case PLAY:		Cgame(this).run();
		}	
	}

	// Create/run the game applet
	//Cgame(this).run();
}
void CApp::runTitle()
{
	curScreen = TITLE;
	
}
void CApp::runControls()
{
	curScreen = CONTROLS;
	
}
void CApp::runPlay()
{
	curScreen = PLAY;
	
}





