#include "mesh.h"
 

Tank::Tank(G3D::Vector3 p,Color3 c,Mesh *m):Particle(p,Vector3(0,0,0),m)
{
	frame = CoordinateFrame(Matrix3::fromAxisAngle(Vector3(0,1,0),0),p);
	cabinFrame = CoordinateFrame(Vector3(0,.24f,.15));
	barrelFrame = CoordinateFrame(Matrix3::fromAxisAngle(Vector3(1,0,0),pi()/4),Vector3(0,0.01f,0));
	this->normal=Vector3(0,1,0);
	heading = 0;
	shotAngle = pi()/4;
	shotDir=0;
	shotAngleMove =0;
	shotDirMove=0;
	shotMode = false;
	Current = false;
	this->color=c;
	this->health =100;
//	this->camera.setPosition(Vector3(pos.x,30,pos.z));
//	this->camera.lookAt(pos,frame.lookVector());
	this->camMode=0;
	this->curr_wep=0;
	this->max_wep=1;
	this->zoom=0;
	this->baseBox=AABox(Vector3(-.30f,0,-.45f),Vector3(.30f,.2f,.45f));
	this->cabinBox=AABox(Vector3(-.075f,0,-.075f),Vector3(.075f,.10f,.075f));
	this->barrelBox=AABox(Vector3(-.025f,-.025f,-.6f),Vector3(.025f,.025f,0));
	this->moved=100;
	this->exploded=false;
}
void Tank::makeProjection()
{
	if(this->alive())
	{
		Particle *b = this->getShotStart(50.0f,false);
		project.fastClear();

		for(RealTime time = 0;time<5;time+=.005)
		{
			project.append(b->getPos());
			b->addForce(Vector3(0,-10,0));
			b->update(.005);
		}
		delete b;
	}
}
void Tank::movez(float zd)
{


		this->thrustF = frame.vectorToWorldSpace(Vector3(0,0,zd));

}
void Tank::angleUpdate(float ang)
{
	shotAngle+=ang;
	if(shotAngle>=G3D::halfPi())
	{
			shotAngle = halfPi();
	}
	if(shotAngle<=G3D::toRadians(-10))
	{
			shotAngle = G3D::toRadians(-10);
	}
	barrelFrame = CoordinateFrame(Matrix3::fromAxisAngle(Vector3(1,0,0),shotAngle));
	//this->shotAngleMove=0;
}
void Tank::angle(float ang)
{
	shotAngleMove=ang;
}

const CoordinateFrame& Tank::getFrame()
{
	return frame;
}
const CoordinateFrame Tank::getCamFrame()
{
	
	switch(camMode)
	{
		//overhead
		case 0:	this->camera.setPosition(Vector3(pos.x,30+zoom,pos.z));
				this->camera.lookAt(pos,frame.lookVector());
				break;
		//first person
		case 1: if(shotMode)
				{
					this->camera.setPosition((frame*cabinFrame*barrelFrame).pointToWorldSpace(Vector3(0,0,0)));
					this->camera.lookAt((frame*cabinFrame*barrelFrame).pointToWorldSpace(Vector3(0,0,-1)),(frame*cabinFrame*barrelFrame).upVector());
				}
				else
				{
					this->camera.setPosition(frame.pointToWorldSpace(Vector3(0,.24,.150)));
					this->camera.lookAt(frame.pointToWorldSpace(Vector3(0,.24,-1)),frame.upVector());
				}
				break;
		
		//third person
		case 2:	
				if(shotMode)
				{
					this->camera.setPosition((frame*cabinFrame).pointToWorldSpace(Vector3(0,.5,4+zoom/10.0f)));
					this->camera.lookAt((frame*cabinFrame).pointToWorldSpace(Vector3(0,.5,-1)),frame.upVector());
				}
				else
				{
					this->camera.setPosition(frame.pointToWorldSpace(Vector3(0,1,4+zoom/10.0f)));
					this->camera.lookAt(frame.pointToWorldSpace(Vector3(0,1,-1)),frame.upVector());
				}
				break;
	}
	

	return camera.getCoordinateFrame();
}
void Tank::cycleCam()
{
	camMode++;
	if(camMode>2)
		camMode=0;
	zoom=0;
}
void Tank::cycleWep()
{
	curr_wep++;
	if(curr_wep>max_wep)
		curr_wep=0;
}
void Tank::rotate(float rt)
{
	this->shotDirMove=rt;
}
void Tank::rotateUpdate(float rt)
{
	if(!shotMode)
	{
		heading +=rt;
		if(heading>=G3D::twoPi())
		{
			heading -= twoPi();
		}
	
		frame.rotation = CoordinateFrame(Matrix3::fromAxisAngle(Vector3(0,1,0),heading)).rotation;
		fixNormal(normal);
	}
	else
	{
		shotDir +=rt*.5f;
		if(shotDir>=G3D::twoPi())
		{
			shotDir -= twoPi();
		}
		cabinFrame.rotation = CoordinateFrame(Matrix3::fromAxisAngle(Vector3(0,1,0),shotDir)).rotation;
	}
	//this->shotDirMove=0;
}
void Tank::render(G3D::RenderDevice *rd)
{
if(!(Current&&(camMode==1)))
{
	rd->pushState();
		rd->setTexture(3,NULL);
		rd->setColor(color);
		rd->setObjectToWorldMatrix(frame);
			//Draw::axes(rd);
			//Draw::box(baseBox,rd,Color4(color,.5));
			for(int i=0;i<Tank::base_mod.size();i++)
				Tank::base_mod[i]->render(rd);

			rd->setObjectToWorldMatrix(frame*cabinFrame);
			//	Draw::box(cabinBox,rd,Color4(color,.5));
			for(int i=0;i<Tank::cabin_mod.size();i++)
				Tank::cabin_mod[i]->render(rd);
			
				rd->setObjectToWorldMatrix(frame*cabinFrame*barrelFrame);
				for(int i=0;i<Tank::turret_mod.size();i++)
					Tank::turret_mod[i]->render(rd);
	
				//Draw::box(barrelBox,rd,Color4(color,.5));
	rd->popState();
		

	Color3 csd = Color3::yellow();
	//if(shotMode)
	//	csd = color.cross(Color3::yellow());
	//Draw::sphere(Sphere(this->getPos(),.5),rd,Color4(csd,.5));
	//if(Current)
	//	Draw::sphere(Sphere(this->getPos(),1),rd,Color4(Color3::red(),.1),Color4(Color3::red(),.1));

	
/*	Vector3 p3d =frame.pointToWorldSpace(Vector3(0,.8,0));
	rd->disableLighting();
	rd->setColor(Color3::green());
	rd->beginPrimitive(RenderDevice::QUADS);
	rd->sendVertex(p3d+Vector3(0,0,0));
	rd->sendVertex(p3d+Vector3(health/100,0,0));
	rd->sendVertex(p3d+Vector3(health/100,.25f,0));
	rd->sendVertex(p3d+Vector3(0,.25f,0));

	rd->sendVertex(p3d+Vector3(0,.25f,0));
	rd->sendVertex(p3d+Vector3(health/100,.25f,0));
	rd->sendVertex(p3d+Vector3(health/100,0,0));
	rd->sendVertex(p3d+Vector3(0,0,0));
	
	rd->endPrimitive();*/
}
	if(Current&&shotMode&&curr_wep!=1)
	{
		glLineWidth(3);
		rd->beginPrimitive(RenderDevice::LINE_STRIP);
		rd->setColor(Color3::gray());
		for(int i=0;i<project.size();i++)
			rd->sendVertex(project[i]);
		rd->endPrimitive();
	}
	rd->enableLighting();
	rd->setShininess(255);
	rd->setSpecularCoefficient(0);

}
void Tank::flipCurrent()
{
	Current=!Current;
	if(Current)
		makeProjection();

}

Particle* Tank::getShotStart(float pow,bool reset)
{
	
	Vector3 p = (frame*cabinFrame*barrelFrame).pointToWorldSpace(Vector3(0,0.025f,-.65f));
	Vector3 v = (frame*cabinFrame*barrelFrame).vectorToWorldSpace(Vector3(0,0,-.1*pow));

	Particle *b=new Particle(Vector3(0,0,0),Vector3(0,0,0),mesh);
	switch(curr_wep)
	{
		case 0:	b=new Particle(p,v,mesh);
				break;
		case 1: b=new Laser(p,v,mesh);
				break;
	}
	if(reset)
		this->shotMode=false;
	return b;
}
void Tank::update(RealTime time)
{
	if(this->pos.y<2.5f)
		this->health=0;
	if(alive())
	{
		Particle::update(time);
		
	//	thrustF = Vector3::zero();
		frame.translation = pos;
	/*	if(this->shotMode&&(this->shotAngleMove!=0||this->shotDirMove!=0))
		{
			this->makeProjection();
		}*/
		if(this->shotAngleMove!=0)
		{
			angleUpdate(shotAngleMove*time);
		}
		if(this->shotDirMove!=0)
		{
			rotateUpdate(shotDirMove*time);
		}

	
	
	}
}
void Tank::resetStates()
{
	thrustF = Vector3::zero();
	this->shotAngleMove=0;
	this->shotDirMove=0;
	this->makeProjection();
	

}
void Tank::zoomCam(float za)
{
	zoom+=za;
	if(zoom<0)
		zoom=0;
	if(zoom>20.0f)
		zoom=20.0f;
}
void Tank::setPoint(Vector3 point)
{
	frame.translation = point;
	pos = point; 
}
void Tank::fixNormal(Vector3 nor)
{
	this->normal=nor;
	Vector3 rot = nor.cross(Vector3(0,1,0)).directionOrZero();
	double angle= G3D::aCos(nor.dot(Vector3(0,1,0)));
	if(rot!=Vector3(0,0,0))
	{
		frame.rotation=(CoordinateFrame(Matrix3::fromAxisAngle(rot,-angle))).rotation;
		frame = frame*(CoordinateFrame(Matrix3::fromAxisAngle(Vector3(0,1,0),heading)));
	}
}
const Vector3& Tank::getThrustForce()
{
	return thrustF;
}
const Vector3& Tank::getNormal()
{
	return normal;
}
bool Tank::intersect(Particle *part,Vector3 &res)
{
	Vector3 testPos=part->getPPos();
	Vector3 testVel=part->getPos()-part->getPPos();


	if(CollisionDetection::collisionTimeForMovingPointFixedAABox(frame.pointToObjectSpace(testPos),frame.vectorToObjectSpace(part->getPos()-part->getPPos()),baseBox,res)<1.0f)
	{	
		res=frame.pointToWorldSpace(res);
		return true;
	}
	/*if(CollisionDetection::collisionLocationForMovingPointFixedAABox(part->getPPos(),part->getPos()-part->getPPos(),cabinBox,res))
		return true;
	if(CollisionDetection::collisionLocationForMovingPointFixedAABox(part->getPPos(),part->getPos()-part->getPPos(),turretBox,res))
		return true;
*/
	return false;
}
Particle::Particle(G3D::Vector3 p, G3D::Vector3 v,Mesh *m)
{
	pos=Vector3(p);
	ppos=Vector3(p);
	vel=Vector3(v*2);
	force=Vector3(0,0,0);
	go = false;
	endAni=false;
	aniTime=0;
	cueDeform=0;
	mesh=m;
	GCamera cftemp;
	cftemp.setPosition(Vector3(0,0,0));
	cftemp.lookAt(vel);
	frame=cftemp.getCoordinateFrame();
	sphereRad=2;
}
void Particle::intersect(Tank *tank)
{
	Vector3 res;
	if(tank->intersect(this,res))
	{
		setGo(true);
		setInter(res);
	}

}
void Laser::intersect(Tank *tank)
{
	
	Particle::intersect(tank);
	if(go)tank->damage(20);
}
void Particle::addForce(G3D::Vector3 f)
{
	force+=f;
}
void Particle::update(RealTime time)
{
	
	if(!go)
	{
		vel = vel + force*time;
		
		Vector3 tpos = pos+vel*time;
		if(tpos!=pos)
			ppos=pos;//-vel*time;
		pos=tpos;
		force.x=0;force.y=0;force.z=0;

		GCamera cmatemp;
		cmatemp.setPosition(pos);
		cmatemp.lookAt(pos+vel);
		//frame.translation=pos;
		//frame.lookAt(pos+vel);
		frame=cmatemp.getCoordinateFrame();
	}
	else
	{
		//if(expos.size()==0)
	//	{
			for(int i=0;i<8;i++)
			{
				expos.append(ppos);
				exforce.append(Vector3::random()*15);
				exrot.append(Vector3::random());
				exmass.append(uniformRandom(0.3,1));
				exang.append( uniformRandom(0,twoPi()));
				exgo.append(true);
			}
	//	}
	//	else
	//	{
			for(int i=0;i<expos.size();i++)
			{
				if(exgo[i])
				{	
				//	exforce[i]+= Vector3(0,1,0)*(4-(expos[i]-pos).magnitude());
					if(mesh->valueAt(expos[i])>0)
					{
						exforce[i] = exforce[i].reflectionDirection(mesh->normalAt(expos[i]))*exforce[i].magnitude();
					}
					exforce[i] = exforce[i] - (exforce[i]*time*10)/exmass[i];
					
					expos[i]= expos[i] + exforce[i]*time;
					exang[i] =exang[i] + 10*time;
					if(exang[i]> twoPi())
						exang[i]=exang[i] - twoPi();
					if(exforce[i].squaredMagnitude()<.1)
						exgo[i]=false;
				}
			}
	//	}
		aniTime+= time;
		if(aniTime>.5)
			cueDeform++;
		if(aniTime>5)
			this->endAni=true;
	}
}
void Particle::render(RenderDevice *rd)
{
	rd->pushState();
	if(!go)
	{
		/*glPointSize(3);
		rd->setColor(Color3::yellow());
		rd->disableLighting();
		rd->setTexture(3,NULL);
		rd->beginPrimitive(RenderDevice::POINTS);
		rd->sendVertex(pos);
		
		rd->endPrimitive();*/
		rd->setColor(Color3::brown());
		rd->setObjectToWorldMatrix(frame);
		
		for(int i=0;i<Particle::misil_mod.size();i++)
				Particle::misil_mod[i]->render(rd);
	}
	else
	{
		float rad = aniTime*2.0f;
		if(rad>2)
			rad=2;
		Color4 exCol1;
		Color4 exCol;

		//if(aniTime<=1)
		//	exCol = Color3::jetColorMap(aniTime);
		//else
	//	{
	//	exCol = Color4(Color3::jetColorMap(aniTime),.25-aniTime/16);
	//	exCol1 = Color4(exColor(aniTime/2),.04);
	//	}
	//	Draw::sphere(Sphere(pos,rad),rd,exCol1,exCol1);
		glPointSize(6);
		rd->disableDepthWrite();
		rd->setBlendFunc(RenderDevice::BlendFunc::BLEND_SRC_ALPHA,
						 RenderDevice::BlendFunc::BLEND_ONE_MINUS_SRC_ALPHA,
						 RenderDevice::BlendEq::BLENDEQ_ADD);
					
		rd->pushState();
		rd->enableLighting();
		rd->setColor(exCol1);
		rd->setTextureCombineMode(3,RenderDevice::CombineMode::TEX_MODULATE);
		//rd->beginPrimitive(RenderDevice::TRIANGLES);
		for(int i=0;i<expos.size();i++)
		{
		/*	rd->sendVertex(expos[i]);
			rd->sendVertex(expos[i] + Vector3(.5,.5,.5));
			rd->sendVertex(pos);

			rd->sendVertex(pos);
			rd->sendVertex(expos[i]  + Vector3(.5,.5,.5) );
			rd->sendVertex(expos[i]);*/
			if(exgo[i])
			{
				exCol1 = exColor((expos[i]-pos).magnitude());
				if(aniTime>1)
					exCol1.a = exCol1.a*(2-aniTime);
				rd->setColor(exCol1);
				rd->setObjectToWorldMatrix(CoordinateFrame(Matrix3::fromAxisAngle(exrot[i],exang[i])*(expos[i]-pos).magnitude()*2,expos[i]));
				glCallList(1);
			}
		}
		//rd->endPrimitive();
		rd->disableLighting();
		rd->popState();
		rd->enableDepthWrite();
	}
	rd->popState();
	
}
void Laser::update(RealTime time)
{
	
	if(!go)
	{
		Vector3 tpos = pos+vel*time;
		if(tpos!=pos)
			ppos=pos;//-vel*time;
		pos=tpos;
		frame.translation=pos;
		this->aniTime+=time*5;
		if(aniTime>2)
			aniTime=0;

	}else
	{
		this->aniTime+=time;
		if(aniTime>2.0f)
			endAni=true;
	}
	
}
void Laser::render(RenderDevice *rd)
{
	if(!go)
	{
		//glPointSize(3);
		rd->pushState();
		rd->setTexture(3,NULL);
		float jc=aniTime>1?2-aniTime:aniTime;
		
		rd->setColor(Color3::jetColorMap(jc));
		//rd->disableLighting();
		rd->setObjectToWorldMatrix(frame);
		glCallList(2);
		//rd->enableLighting();
		rd->popState();
	}
	else
	{
		float timenum=G3D::min<float>(aniTime,.5f);
		
		rd->pushState();
		rd->setTexture(3,NULL);
		float alp =1;
		if(aniTime>.5f)
		{	alp=1.5f-aniTime;
		rd->setBlendFunc(RenderDevice::BlendFunc::BLEND_SRC_ALPHA,
						 RenderDevice::BlendFunc::BLEND_ONE_MINUS_SRC_ALPHA,
						 RenderDevice::BlendEq::BLENDEQ_ADD);
		}
		rd->setColor(Color4(Color3::jetColorMap(timenum*2),alp));
		rd->setObjectToWorldMatrix(CoordinateFrame(Matrix3::identity()*timenum,pos));
		glCallList(1);
		rd->popState();
	}
	
	
}
Color4 Particle::exColor(float c)
{
	if(c<=1.0f/3.0f)
	{
		return Color4(1.0f,1.0f,1.0f-c*3.0f,.04f);
	}
	else if(c>(1.0f/3.0f)&&c<=(2.0f/3.0f))
	{
		return Color4(1.0f,1.0f-(c-(1.0f/3.0f))*(3.0f),0,.04f);
	}
	else if(c>(2.0f/3.0f)&&c<1.0f)
	{
		return Color4(1.0f-(c-(2.0f/3.0f))*(3.0f),0,0,.004f);
	}

	return Color4(Color3::black(),.0004f);
}
const Vector3& Particle::getPos()
{
	return pos;
}
const Vector3& Particle::getPPos()
{
	return ppos;
}
const Vector3& Particle::getVel()
{
	return vel;
}
const Vector3& Particle::getInter()
{
	return inter;
}
void Particle::setVel(const Vector3 &newV)
{
	vel=newV;
}
void Particle::setInter(const G3D::Vector3 &i)
{
	this->inter=i;
}