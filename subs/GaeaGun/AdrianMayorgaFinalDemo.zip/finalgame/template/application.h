///////////////////////////////////////////////////////////////////////
//
//  File				:	application.h
//  Classes				:	CApp
//  Description			:	This file holds the main application class
//
////////////////////////////////////////////////////////////////////////
#ifndef APPLICATION_H
#define APPLICATION_H

// The main G3D header 
#include <G3DAll.h>
#include "template.h"
#include "controls.h"
#include "game.h"



///////////////////////////////////////////////////////////////////////
// Class				:	CApp
// Description			:	This class holds the application data
// Comments				:	Put the data that will persist throut the application here
class CApp : public GApp {
public:
					CApp(const GAppSettings& settings);
					~CApp();
	void			runTitle();
	void			runControls();
	void			runPlay();	
	enum CurScreen {TITLE,CONTROLS,PLAY};
	
protected:
	void			main();
	CurScreen		curScreen;
	

};


#endif




