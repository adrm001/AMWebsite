#ifndef TANK_H
#define TANK_H

// The main G3D header
#include <G3DAll.h>
#include "ArticulatedModel.h"

class Mesh;
class Tank;

class Particle{
public:
	Particle(Vector3 p,Vector3 v,Mesh *m);
	Particle(){go=false;}
	~Particle(){}
	virtual void update(RealTime time);
	void addForce(Vector3 f);
	virtual void render(RenderDevice *rd);
	const Vector3& getPos();
	const Vector3& getPPos();
	const Vector3& getVel();
	void setVel(const Vector3 &newV);
	void setInter(const Vector3 &i);
	const Vector3& getInter();
	void setGo(bool g){go=g;aniTime=0;}
	bool getGo(){return go;}
	bool getAniEnd(){return endAni;}
	int getDeform(){return cueDeform;}
	float getSphere(){return sphereRad;}
	virtual void intersect(Tank *tank);
	static ArticulatedModelRef model_misil;
	static Array<PosedModelRef> misil_mod;

protected:
	Vector3 pos;
	Vector3 ppos;
	Vector3 vel;
	Vector3 force;
	Vector3 inter;
	Color4 exColor(float c);
	bool go;
	bool endAni;

	int cueDeform;
	float sphereRad;
	RealTime aniTime;
	CoordinateFrame frame;
	
	Array<Vector3> expos;
	Array<Vector3> exforce;
	Array<Vector3> exrot;
	Array<float>   exmass;
	Array<float>   exang;
	Array<bool>    exgo;
	Mesh *mesh;

};

class Laser:public Particle{
public:
	Laser(Vector3 p,Vector3 v,Mesh *m):Particle(p,v.direction()*10.0f,m){sphereRad=0;};
	Laser(){go=false;}
	~Laser(){}
	void update(RealTime time);
	void render(RenderDevice *rd);
	void intersect(Tank *tank);
	

};

class Tank:public Particle{
public:
	Tank(){}
	Tank(Vector3 p,Color3 c,Mesh *m);
	~Tank(){}
	void	render(RenderDevice *rd);
	void	movez(float zd);
	void	rotate(float rt);
	
	void	updateRot();
	const CoordinateFrame& getFrame();
	const CoordinateFrame getCamFrame();

	void	angle(float ang);
	bool	getShotMode(){return shotMode;}
	int		getCurrWep(){return curr_wep;}
	int		getCamMode(){return camMode;}
	void	setShotMode(bool mode){shotMode=mode;if(mode==true) makeProjection();}
	Particle*	getShotStart(float pow,bool reset=true);
	void update(RealTime time);
	void setPoint(Vector3 point);
	void fixNormal(Vector3 nor);
	void flipCurrent();

	void damage(float dam){health-=dam;}
	bool alive(){return health>0;}
	float getHealth(){return health;}
	void cycleCam();
	void cycleWep();
	void zoomCam(float za);

	const Vector3& getThrustForce();
	const Vector3& getNormal();
	void resetStates();
	void	makeProjection();
	float moved;
	float getZoom(){return zoom;}
	bool intersect(Particle *part,Vector3 &res);
	bool exploded;
	static ArticulatedModelRef model_base;
	static ArticulatedModelRef model_cabin;
	static ArticulatedModelRef model_turret;
	static Array<PosedModelRef> base_mod;
	static Array<PosedModelRef> cabin_mod;
	static Array<PosedModelRef> turret_mod;


	
private:
	void	rotateUpdate(float rt);
	void	angleUpdate(float ang);
	float zoom;


	CoordinateFrame frame;
	CoordinateFrame cabinFrame;
	CoordinateFrame barrelFrame;
	GCamera camera;

	Color3 color;
	Vector3 normal;
	Vector3 thrustF;
	Array<Vector3>  project;

	float heading;
	float shotDir;
	float shotAngle;
	float shotDirMove;
	float shotAngleMove;
	AABox baseBox;
	AABox cabinBox;
	AABox barrelBox;

	float health;
	bool shotMode;
	bool Current;
	int camMode;
	int curr_wep;
	int max_wep;
};

#endif